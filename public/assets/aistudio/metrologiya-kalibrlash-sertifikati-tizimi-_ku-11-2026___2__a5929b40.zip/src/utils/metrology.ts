import { 
  ChamberPointId, 
  ChamberPointData, 
  CalibrationItemInfo, 
  ChamberCalculation, 
  PointStat 
} from '../types';

export function parseCellValue(val: number | string | undefined | null): number | null {
  if (val === undefined || val === null) return null;
  if (typeof val === 'number') return isNaN(val) ? null : val;
  const str = String(val).replace(',', '.').trim();
  if (str === '' || str === '-' || str === '+') return null;
  const parsed = parseFloat(str);
  return isNaN(parsed) ? null : parsed;
}

export function calculateMean(values: number[]): number {
  if (values.length === 0) return 0;
  const sum = values.reduce((acc, curr) => acc + curr, 0);
  return sum / values.length;
}

export function calculateTypeAUncertainty(values: number[], mean?: number): number {
  const n = values.length;
  if (n <= 1) return 0;
  const avg = mean !== undefined ? mean : calculateMean(values);
  const sumSquaredDiffs = values.reduce((acc, curr) => acc + Math.pow(curr - avg, 2), 0);
  return Math.sqrt(sumSquaredDiffs / (n * (n - 1)));
}

export function calculateInstabilityDelta(values: number[], mean?: number): number {
  if (values.length === 0) return 0;
  const avg = mean !== undefined ? mean : calculateMean(values);
  let maxDiff = 0;
  for (const val of values) {
    const diff = Math.abs(val - avg);
    if (diff > maxDiff) maxDiff = diff;
  }
  return maxDiff;
}

export function formatMetrologyNumber(
  val: number | string | undefined | null, 
  decimals: number = 3, 
  useComma: boolean = true
): string {
  if (val === undefined || val === null || val === '') return '';
  const num = typeof val === 'number' ? val : parseFloat(String(val).replace(',', '.'));
  if (isNaN(num)) return '';
  const str = num.toFixed(decimals);
  return useComma ? str.replace('.', ',') : str;
}

/**
 * 9 Points definition for Drying Oven chamber (DIN EN 60068-3-5 / KU-10-2025)
 */
export const CHAMBER_POINTS_CONFIG: {
  id: ChamberPointId;
  nameUz: string;
  nameRu: string;
  positionDesc: string;
  coord: [number, number, number];
  isCenter: boolean;
}[] = [
  { id: 'N1', nameUz: 'N1 (Yuqori-Chap-Old)', nameRu: 'N1 (Верх-Лево-Перед)', positionDesc: 'Yuqori old chap burchak', coord: [-1, 1, 1], isCenter: false },
  { id: 'N2', nameUz: 'N2 (Yuqori-O‘ng-Old)', nameRu: 'N2 (Верх-Право-Перед)', positionDesc: 'Yuqori old o‘ng burchak', coord: [1, 1, 1], isCenter: false },
  { id: 'N3', nameUz: 'N3 (Yuqori-O‘ng-Orqa)', nameRu: 'N3 (Верх-Право-Зад)', positionDesc: 'Yuqori orqa o‘ng burchak', coord: [1, 1, -1], isCenter: false },
  { id: 'N4', nameUz: 'N4 (Yuqori-Chap-Orqa)', nameRu: 'N4 (Верх-Лево-Зад)', positionDesc: 'Yuqori orqa chap burchak', coord: [-1, 1, -1], isCenter: false },
  { id: 'N5', nameUz: 'N5 (Markaz / Centre)', nameRu: 'N5 (Центр / T_ref)', positionDesc: 'Kamera geometrik markazi (Etalon nuqta)', coord: [0, 0, 0], isCenter: true },
  { id: 'N6', nameUz: 'N6 (Past-Chap-Old)', nameRu: 'N6 (Низ-Лево-Перед)', positionDesc: 'Pastki old chap burchak', coord: [-1, -1, 1], isCenter: false },
  { id: 'N7', nameUz: 'N7 (Past-O‘ng-Old)', nameRu: 'N7 (Низ-Право-Перед)', positionDesc: 'Pastki old o‘ng burchak', coord: [1, -1, 1], isCenter: false },
  { id: 'N8', nameUz: 'N8 (Past-O‘ng-Orqa)', nameRu: 'N8 (Низ-Право-Зад)', positionDesc: 'Pastki orqa o‘ng burchak', coord: [1, -1, -1], isCenter: false },
  { id: 'N9', nameUz: 'N9 (Past-Chap-Orqa)', nameRu: 'N9 (Низ-Лево-Зад)', positionDesc: 'Pastki orqa chap burchak', coord: [-1, -1, -1], isCenter: false },
];

/**
 * Creates completely empty points structure
 */
export function createEmptyChamberPoints(): ChamberPointData[] {
  return CHAMBER_POINTS_CONFIG.map(cfg => ({
    ...cfg,
    rows: Array.from({ length: 10 }, (_, i) => ({
      index: i + 1,
      tStd: '',
      tInd: ''
    }))
  }));
}

/**
 * Empty calibration info for drying oven
 */
export const EMPTY_CALIBRATION_INFO: CalibrationItemInfo = {
  certificateNumber: '',
  orderNumber: '',
  contractNumber: '',
  applicationDate: '',
  contractDate: '',
  issueDate: '',
  calibrationPeriod: '',
  receptionTime: '',
  calibrationTime: '',
  customerName: '',
  customerAddress: '',
  objectName: '',
  objectType: '',
  serialNumber: '',
  resolution: 0.1,
  tempRangeMin: 0,
  tempRangeMax: 0,
  calibrationPoints: [],
  manufacturer: '',
  
  standardName: '',
  standardType: '',
  standardSerial: '',
  standardTraceability: '',
  standardCertUncertainty: 0.1,
  standardResolution: 0.001,
  standardDrift: 0.0,
  
  deltaRadiation: 0.075,
  deltaLoad: 0.092,
  
  ambientTempMin: 0,
  ambientTempMax: 0,
  relativeHumidityMin: 0,
  relativeHumidityMax: 0,
  atmosphericPressureMin: 0,
  atmosphericPressureMax: 0,
  
  calibratedByUz: '',
  calibratedByRu: '',
  checkedByUz: '',
  checkedByRu: '',
  laboratoryNameUz: '',
  laboratoryNameRu: '',
  laboratoryNameEn: '',
  additionalInfo: ''
};

/**
 * Sample dataset loaded directly from attached primary data protocol and methodology KU-10-2025
 */
export const SAMPLE_CHAMBER_POINTS: ChamberPointData[] = [
  {
    id: 'N1',
    nameUz: 'N1 (Yuqori-Chap-Old)',
    nameRu: 'N1 (Верх-Лево-Перед)',
    positionDesc: 'Yuqori old chap burchak',
    coord: [-1, 1, 1],
    isCenter: false,
    rows: [
      { index: 1, tStd: 29.62, tInd: 30.0 },
      { index: 2, tStd: 29.61, tInd: 30.0 },
      { index: 3, tStd: 29.62, tInd: 30.0 },
      { index: 4, tStd: 29.61, tInd: 30.0 },
      { index: 5, tStd: 29.62, tInd: 30.0 },
      { index: 6, tStd: 29.63, tInd: 30.0 },
      { index: 7, tStd: 29.62, tInd: 30.0 },
      { index: 8, tStd: 29.61, tInd: 30.0 },
      { index: 9, tStd: 29.62, tInd: 30.0 },
      { index: 10, tStd: 29.62, tInd: 30.0 }
    ]
  },
  {
    id: 'N2',
    nameUz: 'N2 (Yuqori-O‘ng-Old)',
    nameRu: 'N2 (Верх-Право-Перед)',
    positionDesc: 'Yuqori old o‘ng burchak',
    coord: [1, 1, 1],
    isCenter: false,
    rows: [
      { index: 1, tStd: 29.64, tInd: 30.0 },
      { index: 2, tStd: 29.65, tInd: 30.0 },
      { index: 3, tStd: 29.64, tInd: 30.0 },
      { index: 4, tStd: 29.64, tInd: 30.0 },
      { index: 5, tStd: 29.65, tInd: 30.0 },
      { index: 6, tStd: 29.64, tInd: 30.0 },
      { index: 7, tStd: 29.63, tInd: 30.0 },
      { index: 8, tStd: 29.64, tInd: 30.0 },
      { index: 9, tStd: 29.64, tInd: 30.0 },
      { index: 10, tStd: 29.65, tInd: 30.0 }
    ]
  },
  {
    id: 'N3',
    nameUz: 'N3 (Yuqori-O‘ng-Orqa)',
    nameRu: 'N3 (Верх-Право-Зад)',
    positionDesc: 'Yuqori orqa o‘ng burchak',
    coord: [1, 1, -1],
    isCenter: false,
    rows: [
      { index: 1, tStd: 29.66, tInd: 30.0 },
      { index: 2, tStd: 29.65, tInd: 30.0 },
      { index: 3, tStd: 29.66, tInd: 30.0 },
      { index: 4, tStd: 29.65, tInd: 30.0 },
      { index: 5, tStd: 29.65, tInd: 30.0 },
      { index: 6, tStd: 29.66, tInd: 30.0 },
      { index: 7, tStd: 29.67, tInd: 30.0 },
      { index: 8, tStd: 29.66, tInd: 30.0 },
      { index: 9, tStd: 29.65, tInd: 30.0 },
      { index: 10, tStd: 29.66, tInd: 30.0 }
    ]
  },
  {
    id: 'N4',
    nameUz: 'N4 (Yuqori-Chap-Orqa)',
    nameRu: 'N4 (Верх-Лево-Зад)',
    positionDesc: 'Yuqori orqa chap burchak',
    coord: [-1, 1, -1],
    isCenter: false,
    rows: [
      { index: 1, tStd: 29.59, tInd: 30.0 },
      { index: 2, tStd: 29.60, tInd: 30.0 },
      { index: 3, tStd: 29.59, tInd: 30.0 },
      { index: 4, tStd: 29.60, tInd: 30.0 },
      { index: 5, tStd: 29.59, tInd: 30.0 },
      { index: 6, tStd: 29.59, tInd: 30.0 },
      { index: 7, tStd: 29.60, tInd: 30.0 },
      { index: 8, tStd: 29.59, tInd: 30.0 },
      { index: 9, tStd: 29.60, tInd: 30.0 },
      { index: 10, tStd: 29.59, tInd: 30.0 }
    ]
  },
  {
    id: 'N5',
    nameUz: 'N5 (Markaz / Centre)',
    nameRu: 'N5 (Центр / T_ref)',
    positionDesc: 'Kamera geometrik markazi (Etalon nuqta)',
    coord: [0, 0, 0],
    isCenter: true,
    rows: [
      { index: 1, tStd: 29.661, tInd: 30.0 },
      { index: 2, tStd: 29.652, tInd: 30.0 },
      { index: 3, tStd: 29.553, tInd: 29.9 },
      { index: 4, tStd: 29.604, tInd: 30.0 },
      { index: 5, tStd: 29.664, tInd: 30.0 },
      { index: 6, tStd: 29.684, tInd: 30.0 },
      { index: 7, tStd: 29.696, tInd: 30.0 },
      { index: 8, tStd: 29.615, tInd: 30.0 },
      { index: 9, tStd: 29.621, tInd: 30.0 },
      { index: 10, tStd: 29.612, tInd: 30.0 }
    ]
  },
  {
    id: 'N6',
    nameUz: 'N6 (Past-Chap-Old)',
    nameRu: 'N6 (Низ-Лево-Перед)',
    positionDesc: 'Pastki old chap burchak',
    coord: [-1, -1, 1],
    isCenter: false,
    rows: [
      { index: 1, tStd: 29.56, tInd: 30.0 },
      { index: 2, tStd: 29.56, tInd: 30.0 },
      { index: 3, tStd: 29.55, tInd: 30.0 },
      { index: 4, tStd: 29.56, tInd: 30.0 },
      { index: 5, tStd: 29.57, tInd: 30.0 },
      { index: 6, tStd: 29.56, tInd: 30.0 },
      { index: 7, tStd: 29.56, tInd: 30.0 },
      { index: 8, tStd: 29.55, tInd: 30.0 },
      { index: 9, tStd: 29.56, tInd: 30.0 },
      { index: 10, tStd: 29.56, tInd: 30.0 }
    ]
  },
  {
    id: 'N7',
    nameUz: 'N7 (Past-O‘ng-Old)',
    nameRu: 'N7 (Низ-Право-Перед)',
    positionDesc: 'Pastki old o‘ng burchak',
    coord: [1, -1, 1],
    isCenter: false,
    rows: [
      { index: 1, tStd: 29.54, tInd: 30.0 },
      { index: 2, tStd: 29.52, tInd: 30.0 },
      { index: 3, tStd: 29.54, tInd: 30.0 },
      { index: 4, tStd: 29.54, tInd: 30.0 },
      { index: 5, tStd: 29.53, tInd: 30.0 },
      { index: 6, tStd: 29.54, tInd: 30.0 },
      { index: 7, tStd: 29.55, tInd: 30.0 },
      { index: 8, tStd: 29.54, tInd: 30.0 },
      { index: 9, tStd: 29.53, tInd: 30.0 },
      { index: 10, tStd: 29.54, tInd: 30.0 }
    ]
  },
  {
    id: 'N8',
    nameUz: 'N8 (Past-O‘ng-Orqa)',
    nameRu: 'N8 (Низ-Право-Зад)',
    positionDesc: 'Pastki orqa o‘ng burchak',
    coord: [1, -1, -1],
    isCenter: false,
    rows: [
      { index: 1, tStd: 29.56, tInd: 30.0 },
      { index: 2, tStd: 29.57, tInd: 30.0 },
      { index: 3, tStd: 29.56, tInd: 30.0 },
      { index: 4, tStd: 29.56, tInd: 30.0 },
      { index: 5, tStd: 29.57, tInd: 30.0 },
      { index: 6, tStd: 29.56, tInd: 30.0 },
      { index: 7, tStd: 29.57, tInd: 30.0 },
      { index: 8, tStd: 29.56, tInd: 30.0 },
      { index: 9, tStd: 29.56, tInd: 30.0 },
      { index: 10, tStd: 29.57, tInd: 30.0 }
    ]
  },
  {
    id: 'N9',
    nameUz: 'N9 (Past-Chap-Orqa)',
    nameRu: 'N9 (Низ-Лево-Зад)',
    positionDesc: 'Pastki orqa chap burchak',
    coord: [-1, -1, -1],
    isCenter: false,
    rows: [
      { index: 1, tStd: 29.60, tInd: 30.0 },
      { index: 2, tStd: 29.60, tInd: 30.0 },
      { index: 3, tStd: 29.59, tInd: 30.0 },
      { index: 4, tStd: 29.60, tInd: 30.0 },
      { index: 5, tStd: 29.60, tInd: 30.0 },
      { index: 6, tStd: 29.61, tInd: 30.0 },
      { index: 7, tStd: 29.60, tInd: 30.0 },
      { index: 8, tStd: 29.59, tInd: 30.0 },
      { index: 9, tStd: 29.60, tInd: 30.0 },
      { index: 10, tStd: 29.60, tInd: 30.0 }
    ]
  }
];

export const SAMPLE_CALIBRATION_INFO: CalibrationItemInfo = {
  certificateNumber: 'Uz-112/1-2025',
  orderNumber: '28.04.2025',
  contractNumber: '№ 25-112-xxxxx',
  applicationDate: '2025-04-28',
  contractDate: '2025-04-28',
  issueDate: '29.04.2025',
  calibrationPeriod: '2025-04-29',
  receptionTime: '10:00',
  calibrationTime: '14:30',
  customerName: 'Хорезмский областной отдел санитарно-эпидемиологического спокойствия и здравоохранения',
  customerAddress: 'Xorazm viloyati, Urganch shahri',
  objectName: 'Сушильные шкаф (Quritish shkafi)',
  objectType: 'RTOP-500Y',
  serialNumber: '2333001557',
  resolution: 0.1,
  tempRangeMin: 0.0,
  tempRangeMax: 50.0,
  calibrationPoints: [30],
  manufacturer: 'Xitoy (CN)',
  
  standardName: 'Термометр лабораторный электронный LTA/Б-300МТ',
  standardType: 'LTA/Б-300МТ, STS-200 A 915 (RTC-156B)',
  standardSerial: '№ 871352, № 613343-19',
  standardTraceability: 'UZ-09T/2038-2025, UZ-09T/2039-2025',
  standardCertUncertainty: 0.1,
  standardResolution: 0.001,
  standardDrift: 0.0,
  
  deltaRadiation: 0.075,
  deltaLoad: 0.092,
  
  ambientTempMin: 24.0,
  ambientTempMax: 24.5,
  relativeHumidityMin: 37.7,
  relativeHumidityMax: 38.5,
  atmosphericPressureMin: 1012.2,
  atmosphericPressureMax: 1013.0,
  
  calibratedByUz: 'B. G‘aibnazarov',
  calibratedByRu: 'Гаибназаров Б.',
  checkedByUz: 'M. Yuldoshev',
  checkedByRu: 'Юлдашев М.',
  laboratoryNameUz: 'Harorat va fizik-kimyoviy kattaliklarni o‘lchash laboratoriyasi',
  laboratoryNameRu: 'Калибровочная лаборатория по измерениям температурных и физико-химических величин',
  laboratoryNameEn: 'Calibration laboratory for temperature and physico-chemical quantities',
  additionalInfo: 'KU-10-2025 методики бўйича тўлиқ калибрланган'
};

/**
 * Calculates drying oven / chamber calibration and uncertainty budget according to KU-10-2025
 */
export function calculateChamberKU10Uncertainty(
  points: ChamberPointData[],
  info: CalibrationItemInfo
): ChamberCalculation {
  const targetPoint = info.calibrationPoints[0] ?? 30;
  
  // Calculate stats for each point
  const pointStats: Record<ChamberPointId, PointStat> = {} as any;
  let totalFilledPoints = 0;
  const allStdValues: number[] = [];
  const allIndValues: number[] = [];
  
  // Center point stats
  const centerPoint = points.find(p => p.isCenter) || points[4];
  const centerStdNums = centerPoint.rows
    .map(r => parseCellValue(r.tStd))
    .filter((v): v is number => v !== null);
  const centerIndNums = centerPoint.rows
    .map(r => parseCellValue(r.tInd))
    .filter((v): v is number => v !== null);
    
  const centerStdMean = calculateMean(centerStdNums);
  const centerIndMean = calculateMean(centerIndNums);

  for (const p of points) {
    const stdNums = p.rows.map(r => parseCellValue(r.tStd)).filter((v): v is number => v !== null);
    const indNums = p.rows.map(r => parseCellValue(r.tInd)).filter((v): v is number => v !== null);
    const isEntered = stdNums.length > 0;
    if (isEntered) totalFilledPoints++;
    
    const meanStd = calculateMean(stdNums);
    const meanInd = calculateMean(indNums);
    
    // Difference from center reference: ABS | T_ref - T_i |
    const diffFromCenter = (centerStdNums.length > 0 && stdNums.length > 0)
      ? Math.abs(centerStdMean - meanStd)
      : 0;

    pointStats[p.id] = {
      id: p.id,
      name: p.nameUz,
      meanStd,
      meanInd,
      diffFromCenter,
      isEntered,
      count: stdNums.length
    };
    
    allStdValues.push(...stdNums);
    allIndValues.push(...indNums);
  }

  // If no points entered
  if (totalFilledPoints === 0 || allStdValues.length === 0) {
    return {
      pointTemp: targetPoint,
      n: 0,
      totalFilledPoints: 0,
      pointStats,
      centerStdMean: 0,
      centerIndMean: 0,
      overallStdMean: 0,
      overallIndMean: 0,
      deviation: 0,
      instabilityDelta: 0,
      inhomogeneityDelta: 0,
      radiationDelta: 0,
      loadDelta: 0,
      u_a1: 0,
      u_a2: 0,
      u_b1: 0,
      u_b2: 0,
      u_b3: 0,
      u_b4: 0,
      u_b5: 0,
      u_b6: 0,
      u_b7: 0,
      u_b8: 0,
      u_c: 0,
      k: 2,
      U: 0,
      v_eff: '—'
    };
  }

  const overallStdMean = calculateMean(allStdValues);
  const overallIndMean = calculateMean(allIndValues);
  
  // Reference for spatial evaluation is center point N5 (or overallStdMean if center is empty)
  const tRef = centerStdNums.length > 0 ? centerStdMean : overallStdMean;
  const tIndRef = centerIndNums.length > 0 ? centerIndMean : overallIndMean;
  
  // Deviation: Delta T = T_std - T_ind (or T_ind - T_std)
  const deviation = tRef - tIndRef;
  
  // 1. Standard Type A uncertainty u(T_std) = u_a1 (formula 7 in KU-10-2025)
  // Evaluated on center reference series (or all reference readings)
  const refSeries = centerStdNums.length > 1 ? centerStdNums : allStdValues;
  const u_a1 = calculateTypeAUncertainty(refSeries);

  // 2. Chamber indicator Type A uncertainty u(T_ind) = u_a2 (formula 9 in KU-10-2025)
  const indSeries = centerIndNums.length > 1 ? centerIndNums : allIndValues;
  const u_a2 = calculateTypeAUncertainty(indSeries);

  // 3. Temporal instability delta T_instab = Max | T_bar - T_i | (formula 1 & 10 in KU-10-2025)
  const instabilityDelta = calculateInstabilityDelta(refSeries);
  const u_b1 = instabilityDelta / Math.sqrt(3);

  // 4. Spatial inhomogeneity delta T_inhom = Max | T_ref - T_i | (formula 2 & 11 in KU-10-2025)
  let maxInhom = 0;
  for (const p of points) {
    if (pointStats[p.id].isEntered) {
      const diff = pointStats[p.id].diffFromCenter;
      if (diff > maxInhom) maxInhom = diff;
    }
  }
  const inhomogeneityDelta = maxInhom;
  const u_b2 = inhomogeneityDelta / Math.sqrt(3);

  // 5. Radiation effect delta T_radiation (formula 3 & 12 in KU-10-2025)
  // u_b3 = (0.2 / sqrt(3)) * Max |T_le - T_he|
  const radiationDelta = info.deltaRadiation > 0 ? info.deltaRadiation : 0.075;
  const u_b3 = (0.2 / Math.sqrt(3)) * radiationDelta;

  // 6. Loading effect delta T_load (formula 4 & 13 in KU-10-2025)
  // u_b4 = (0.2 / sqrt(3)) * Max |T_ref - T_ref.load|
  const loadDelta = info.deltaLoad > 0 ? info.deltaLoad : 0.092;
  const u_b4 = (0.2 / Math.sqrt(3)) * loadDelta;

  // 7. Reference standard certificate uncertainty (formula 14 in KU-10-2025)
  // u_b5 = U_cal.std / 2
  const u_cal_std = info.standardCertUncertainty > 0 ? info.standardCertUncertainty : 0.1;
  const u_b5 = u_cal_std / 2;

  // 8. Reference standard resolution uncertainty (formula 15 in KU-10-2025)
  // u_b6 = rez_std / (2 * sqrt(3))
  const rez_std = info.standardResolution > 0 ? info.standardResolution : 0.001;
  const u_b6 = rez_std / (2 * Math.sqrt(3));

  // 9. Chamber resolution uncertainty (formula 16 in KU-10-2025)
  // u_b7 = rez_therm / (2 * sqrt(3))
  const rez_therm = info.resolution > 0 ? info.resolution : 0.1;
  const u_b7 = rez_therm / (2 * Math.sqrt(3));

  // 10. Drift uncertainty (formula 17 in KU-10-2025)
  // u_b8 = delta_d / sqrt(3)
  const u_b8 = (info.standardDrift || 0) / Math.sqrt(3);

  // Combined standard uncertainty u_c (formula 18 in KU-10-2025)
  const sumSquares = 
    Math.pow(u_a1, 2) +
    Math.pow(u_a2, 2) +
    Math.pow(u_b1, 2) +
    Math.pow(u_b2, 2) +
    Math.pow(u_b3, 2) +
    Math.pow(u_b4, 2) +
    Math.pow(u_b5, 2) +
    Math.pow(u_b6, 2) +
    Math.pow(u_b7, 2) +
    Math.pow(u_b8, 2);
    
  const u_c = Math.sqrt(sumSquares);
  const k = 2;
  const U = k * u_c;

  return {
    pointTemp: targetPoint,
    n: refSeries.length,
    totalFilledPoints,
    pointStats,
    centerStdMean,
    centerIndMean,
    overallStdMean,
    overallIndMean,
    deviation,
    instabilityDelta,
    inhomogeneityDelta,
    radiationDelta,
    loadDelta,
    u_a1,
    u_a2,
    u_b1,
    u_b2,
    u_b3,
    u_b4,
    u_b5,
    u_b6,
    u_b7,
    u_b8,
    u_c,
    k,
    U,
    v_eff: '∞'
  };
}
