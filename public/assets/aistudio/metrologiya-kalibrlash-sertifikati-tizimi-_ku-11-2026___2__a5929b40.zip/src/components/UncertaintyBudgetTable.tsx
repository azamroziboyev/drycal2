import React from 'react';
import { ChamberCalculation, CalibrationItemInfo } from '../types';
import { formatMetrologyNumber } from '../utils/metrology';
import { Info } from 'lucide-react';

interface UncertaintyBudgetTableProps {
  calculation: ChamberCalculation;
  info: CalibrationItemInfo;
}

export const UncertaintyBudgetTable: React.FC<UncertaintyBudgetTableProps> = ({
  calculation,
  info,
}) => {
  const c = calculation;

  const budgetItems = [
    {
      sourceRu: 'Показания эталонного термометра (Etalon ko‘rsatkichlari)',
      symbol: 'T_std',
      valueEstimate: `${formatMetrologyNumber(c.centerStdMean, 4)} °C`,
      standardUncertainty: formatMetrologyNumber(c.u_a1, 6),
      type: 'Тип А',
      distribution: 'Нормальное',
      sensitivity: '1',
      contribution: formatMetrologyNumber(c.u_a1, 6),
      formula: 'Формула (6)',
    },
    {
      sourceRu: 'Показания калибруемого шкафа (Quritish shkafi ko‘rsatkichlari)',
      symbol: 'T_ind',
      valueEstimate: `${formatMetrologyNumber(c.centerIndMean, 3)} °C`,
      standardUncertainty: formatMetrologyNumber(c.u_a2, 6),
      type: 'Тип А',
      distribution: 'Нормальное',
      sensitivity: '-1',
      contribution: formatMetrologyNumber(c.u_a2, 6),
      formula: 'Формула (8)',
    },
    {
      sourceRu: 'Поправка временной нестабильности (Vaqt bo‘yicha beqarorlik)',
      symbol: 'δT_instab',
      valueEstimate: `${formatMetrologyNumber(c.instabilityDelta, 4)} °C`,
      standardUncertainty: formatMetrologyNumber(c.u_b1, 6),
      type: 'Тип Б',
      distribution: 'Прямоугольное (1/√3)',
      sensitivity: '1',
      contribution: formatMetrologyNumber(c.u_b1, 6),
      formula: 'Формуla (9)',
    },
    {
      sourceRu: 'Поправка пространственной неоднородности (Fazoviy bir jinsli emaslik - 9 nuqta)',
      symbol: 'δT_inhom',
      valueEstimate: `${formatMetrologyNumber(c.inhomogeneityDelta, 4)} °C`,
      standardUncertainty: formatMetrologyNumber(c.u_b2, 6),
      type: 'Тип Б',
      distribution: 'Прямоугольное (1/√3)',
      sensitivity: '1',
      contribution: formatMetrologyNumber(c.u_b2, 6),
      formula: 'Формула (10)',
    },
    {
      sourceRu: 'Влияние излучения стенок (Devorlar nurlanish ta’siri)',
      symbol: 'δT_rad',
      valueEstimate: `${formatMetrologyNumber(info.deltaRadiation || 0.075, 4)} °C`,
      standardUncertainty: formatMetrologyNumber(c.u_b3, 6),
      type: 'Тип Б',
      distribution: 'Прямоугольное (0.2/√3)',
      sensitivity: '1',
      contribution: formatMetrologyNumber(c.u_b3, 6),
      formula: 'Формула (11)',
    },
    {
      sourceRu: 'Влияние загрузки камеры (Kamera yuklanishi ta’siri)',
      symbol: 'δT_load',
      valueEstimate: `${formatMetrologyNumber(info.deltaLoad || 0.092, 4)} °C`,
      standardUncertainty: formatMetrologyNumber(c.u_b4, 6),
      type: 'Тип Б',
      distribution: 'Прямоугольное (0.2/√3)',
      sensitivity: '1',
      contribution: formatMetrologyNumber(c.u_b4, 6),
      formula: 'Формула (12)',
    },
    {
      sourceRu: 'Значения с сертификата эталона (Etalon sertifikati noaniqligi)',
      symbol: 'δT_cal.std',
      valueEstimate: `${formatMetrologyNumber(info.standardCertUncertainty, 3)} °C`,
      standardUncertainty: formatMetrologyNumber(c.u_b5, 6),
      type: 'Тип Б',
      distribution: 'Нормальное (U/2)',
      sensitivity: '1',
      contribution: formatMetrologyNumber(c.u_b5, 6),
      formula: 'Формула (13)',
    },
    {
      sourceRu: 'Разрешающая способность эталона (Etalon diskretligi)',
      symbol: 'δT_rez.std',
      valueEstimate: `${formatMetrologyNumber(info.standardResolution, 4)} °C`,
      standardUncertainty: formatMetrologyNumber(c.u_b6, 6),
      type: 'Тип Б',
      distribution: 'Прямоугольное (1/2√3)',
      sensitivity: '1',
      contribution: formatMetrologyNumber(c.u_b6, 6),
      formula: 'Формула (14)',
    },
    {
      sourceRu: 'Разрешающая способность шкафа (Quritish shkafi diskretligi)',
      symbol: 'δT_rez.therm',
      valueEstimate: `${formatMetrologyNumber(info.resolution, 3)} °C`,
      standardUncertainty: formatMetrologyNumber(c.u_b7, 6),
      type: 'Тип Б',
      distribution: 'Прямоугольное (1/2√3)',
      sensitivity: '1',
      contribution: formatMetrologyNumber(c.u_b7, 6),
      formula: 'Формула (15)',
    },
    {
      sourceRu: 'Временной дрейф эталона (Etalonning oraliq dreyfi)',
      symbol: 'δT_drift.std',
      valueEstimate: `${formatMetrologyNumber(info.standardDrift || 0, 3)} °C`,
      standardUncertainty: formatMetrologyNumber(c.u_b8, 6),
      type: 'Тип Б',
      distribution: 'Прямоугольное (1/√3)',
      sensitivity: '1',
      contribution: formatMetrologyNumber(c.u_b8, 6),
      formula: 'Формула (16)',
    },
  ];

  return (
    <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800 gap-2">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider text-emerald-600 dark:text-emerald-400">
              Noaniqlik byudjeti
            </span>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-mono font-medium">
              Nuqta: {c.pointTemp} °C • {c.totalFilledPoints}/9 nuqta
            </span>
          </div>
          <h3 className="text-base font-bold text-slate-900 dark:text-white mt-1">
            Quritish Shkafi Noaniqlik Byudjeti (Бюджет неопределенности)
          </h3>
        </div>

        <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
          <Info className="w-4 h-4 text-emerald-500" />
          <span>DIN EN 60068-3-5 & EURAMET cg-20</span>
        </div>
      </div>

      {/* Budget Table */}
      <div className="overflow-x-auto mt-4">
        <table className="w-full text-left text-xs border-collapse">
          <thead>
            <tr className="bg-slate-50 dark:bg-slate-800/80 text-slate-700 dark:text-slate-300 border-b border-slate-200 dark:border-slate-700">
              <th className="py-2.5 px-3 font-semibold">№</th>
              <th className="py-2.5 px-3 font-semibold">Noaniqlik manbai (Источник неопределенности)</th>
              <th className="py-2.5 px-3 font-semibold">Belgisi</th>
              <th className="py-2.5 px-3 font-semibold text-right">Kirish qiymati</th>
              <th className="py-2.5 px-3 font-semibold text-right">Standart noaniqlik, u(x)</th>
              <th className="py-2.5 px-3 font-semibold text-center">Baholash turi</th>
              <th className="py-2.5 px-3 font-semibold text-center">Sezgirlik koeff.</th>
              <th className="py-2.5 px-3 font-semibold text-right">Hissa, u_i(y)</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
            {budgetItems.map((item, idx) => (
              <tr key={idx} className="hover:bg-slate-50/70 dark:hover:bg-slate-800/40 transition-colors">
                <td className="py-2 px-3 text-slate-400 font-mono">{idx + 1}</td>
                <td className="py-2 px-3 font-medium text-slate-800 dark:text-slate-200">
                  {item.sourceRu}
                  <span className="block text-[10px] text-slate-400 font-mono mt-0.5">
                    {item.formula} • {item.distribution}
                  </span>
                </td>
                <td className="py-2 px-3 font-mono font-semibold text-emerald-600 dark:text-emerald-400">
                  {item.symbol}
                </td>
                <td className="py-2 px-3 text-right font-mono text-slate-700 dark:text-slate-300">
                  {item.valueEstimate}
                </td>
                <td className="py-2 px-3 text-right font-mono font-semibold text-slate-900 dark:text-white">
                  {item.standardUncertainty}
                </td>
                <td className="py-2 px-3 text-center">
                  <span
                    className={`inline-block px-2 py-0.5 rounded text-[10px] font-semibold ${
                      item.type === 'Тип А'
                        ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                        : 'bg-indigo-100 text-indigo-800 dark:bg-indigo-950 dark:text-indigo-300'
                    }`}
                  >
                    {item.type}
                  </span>
                </td>
                <td className="py-2 px-3 text-center font-mono text-slate-600 dark:text-slate-400">
                  {item.sensitivity}
                </td>
                <td className="py-2 px-3 text-right font-mono font-bold text-slate-800 dark:text-slate-200">
                  {item.contribution}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Summary KPI cards - Emerald & Slate palette per user request */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 mt-6 pt-5 border-t border-slate-100 dark:border-slate-800">
        {/* Combined uncertainty u_c */}
        <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700">
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
            <span className="font-medium">Yig‘indi standart noaniqlik</span>
            <span className="font-mono font-bold text-slate-700 dark:text-slate-300">u_c</span>
          </div>
          <div className="text-xl font-bold font-mono text-slate-900 dark:text-white mt-1">
            {formatMetrologyNumber(c.u_c, 5)} <span className="text-xs font-normal text-slate-500">°C</span>
          </div>
          <div className="text-[11px] text-slate-400 mt-1 font-mono">
            √(u_a1² + u_a2² + ∑u_bi²)
          </div>
        </div>

        {/* Inhomogeneity delta */}
        <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700">
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
            <span className="font-medium">Bir jinsli emaslik</span>
            <span className="font-mono font-bold text-slate-700 dark:text-slate-300">δT_inhom</span>
          </div>
          <div className="text-xl font-bold font-mono text-slate-900 dark:text-white mt-1">
            {formatMetrologyNumber(c.inhomogeneityDelta, 3)} <span className="text-xs font-normal text-slate-500">°C</span>
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            Max |T_ref - T_i| (9 nuqta bo'yicha)
          </div>
        </div>

        {/* Instability delta */}
        <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700">
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
            <span className="font-medium">Vaqt bo‘yicha beqarorlik</span>
            <span className="font-mono font-bold text-slate-700 dark:text-slate-300">δT_instab</span>
          </div>
          <div className="text-xl font-bold font-mono text-slate-900 dark:text-white mt-1">
            {formatMetrologyNumber(c.instabilityDelta, 3)} <span className="text-xs font-normal text-slate-500">°C</span>
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            Max |T_ref - T_bar| (Markaz tebranishi)
          </div>
        </div>

        {/* Expanded uncertainty U - Styled with elegant Emerald Gradient per user request */}
        <div className="p-4 rounded-xl bg-gradient-to-br from-emerald-50 to-teal-50 dark:from-emerald-950/40 dark:to-teal-950/30 border border-emerald-300 dark:border-emerald-800/80 shadow-sm">
          <div className="flex items-center justify-between text-xs text-emerald-800 dark:text-emerald-300">
            <span className="font-semibold uppercase tracking-wide">Kengaytirilgan noaniqlik</span>
            <span className="font-mono font-bold bg-emerald-200/60 dark:bg-emerald-900/60 px-1.5 py-0.5 rounded text-[10px]">
              k = {c.k}
            </span>
          </div>
          <div className="text-2xl font-black font-mono text-emerald-950 dark:text-emerald-200 mt-1">
            {formatMetrologyNumber(c.U, 2)} <span className="text-xs font-normal text-emerald-700 dark:text-emerald-400">°C</span>
          </div>
          <div className="text-[11px] text-emerald-700 dark:text-emerald-400 mt-1 font-medium">
            U = k × u_c (Ishonch ehtimoli P ≈ 95%)
          </div>
        </div>
      </div>
    </div>
  );
};
