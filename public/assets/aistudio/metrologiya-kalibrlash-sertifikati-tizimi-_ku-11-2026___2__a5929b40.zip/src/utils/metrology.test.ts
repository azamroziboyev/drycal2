import test from 'node:test';
import assert from 'node:assert/strict';
import {
  calculateMean,
  calculateTypeAUncertainty,
  calculateInstabilityDelta,
  calculateChamberKU10Uncertainty,
  SAMPLE_CHAMBER_POINTS,
  SAMPLE_CALIBRATION_INFO,
} from './metrology';

test('calculateMean calculates arithmetic mean correctly', () => {
  const vals = [10, 20, 30];
  assert.equal(calculateMean(vals), 20);
});

test('calculateTypeAUncertainty calculates sample std dev / sqrt(n)', () => {
  const vals = [30.01, 30.02, 30.01, 30.03, 30.01, 30.02, 30.01, 30.02, 30.01, 30.02];
  const mean = calculateMean(vals);
  const u_a = calculateTypeAUncertainty(vals, mean);
  assert.ok(u_a > 0 && u_a < 0.01);
});

test('calculateChamberKU10Uncertainty executes on 9-point sample data from user files', () => {
  const result = calculateChamberKU10Uncertainty(SAMPLE_CHAMBER_POINTS, SAMPLE_CALIBRATION_INFO);

  assert.equal(result.totalFilledPoints, 9);
  assert.equal(result.pointTemp, 30);
  assert.equal(result.n, 10);

  // Center (N5) checks
  assert.ok(result.centerStdMean > 29.5 && result.centerStdMean < 29.8);
  assert.ok(result.centerIndMean >= 29.9 && result.centerIndMean <= 30.0);

  // Instability and Inhomogeneity
  assert.ok(result.instabilityDelta >= 0);
  assert.ok(result.inhomogeneityDelta >= 0);

  // u_b5 = U_cal.std / 2 = 0.1 / 2 = 0.05
  assert.ok(Math.abs(result.u_b5 - 0.05) < 0.0001);

  // Combined uncertainty u_c and expanded uncertainty U
  assert.ok(result.u_c > 0.05);
  assert.ok(result.U >= 0.1);
  assert.equal(result.k, 2);
});
