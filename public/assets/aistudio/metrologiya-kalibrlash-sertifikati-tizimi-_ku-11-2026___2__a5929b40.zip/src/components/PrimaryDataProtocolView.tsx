import React from 'react';
import { CalibrationItemInfo, ChamberPointData, ChamberCalculation } from '../types';
import { formatMetrologyNumber } from '../utils/metrology';
import { Printer, Download, ArrowLeft } from 'lucide-react';
import { downloadElementAsPdf } from '../utils/pdfGenerator';

interface PrimaryDataProtocolViewProps {
  info: CalibrationItemInfo;
  pointsData: ChamberPointData[];
  calculation: ChamberCalculation;
  onBackToEdit: () => void;
}

export const PrimaryDataProtocolView: React.FC<PrimaryDataProtocolViewProps> = ({
  info,
  pointsData,
  calculation,
  onBackToEdit,
}) => {
  const handlePrint = () => {
    window.print();
  };

  const handleDownloadProtocol = async () => {
    try {
      await downloadElementAsPdf(
        ['protocol-content-sheet'],
        `Birlamchi_bayonnoma_${info.certificateNumber.replace(/[\/\\]/g, '_')}.pdf`
      );
    } catch (e) {
      window.print();
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Action Bar */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4 print:hidden">
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={onBackToEdit}
            className="p-2 rounded-xl text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
            title="Ortga qaytish"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h2 className="text-base font-bold text-slate-900 dark:text-white">
              Quritish Shkafi Birlamchi O‘lchash Bayonnomasi (9 Nuqta)
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              N1 dan N9 gacha barcha nuqtalar bo'yicha laboratoriya sinov ma'lumotlari
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handlePrint}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 transition-colors cursor-pointer"
          >
            <Printer className="w-4 h-4 text-slate-500" />
            <span>Chop etish</span>
          </button>

          <button
            type="button"
            onClick={handleDownloadProtocol}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold bg-blue-600 hover:bg-blue-700 text-white shadow-sm shadow-blue-500/20 transition-all cursor-pointer"
          >
            <Download className="w-4 h-4" />
            <span>PDF yuklab olish</span>
          </button>
        </div>
      </div>

      {/* Protocol Paper Sheet */}
      <div className="flex justify-center bg-slate-200 dark:bg-slate-950 p-4 rounded-2xl overflow-x-auto">
        <div
          id="protocol-content-sheet"
          className="w-[210mm] min-h-[297mm] p-[14mm] bg-white text-black shadow-xl text-[11px] leading-normal box-border print:shadow-none print:m-0 print:p-[10mm]"
          style={{ fontFamily: 'Arial, sans-serif' }}
        >
          {/* Header */}
          <div className="text-center font-bold text-base uppercase border-b-2 border-black pb-2 mb-4">
            ПЕРВИЧНЫЕ ДАННЫЕ КАЛИБРОВКИ СУШИЛЬНОГО ШКАФА
            <div className="text-xs font-normal normal-case mt-1 text-slate-700">
              Номер: <span className="font-bold underline">{info.certificateNumber}</span> от {info.issueDate}
            </div>
          </div>

          {/* Details Table */}
          <table className="w-full border-collapse border border-black text-xs mb-4">
            <tbody>
              <tr>
                <td className="border border-black p-1.5 font-bold bg-slate-100 w-1/4">Заказчик / Buyurtmachi:</td>
                <td className="border border-black p-1.5" colSpan={3}>
                  {info.customerName}
                </td>
              </tr>
              <tr>
                <td className="border border-black p-1.5 font-bold bg-slate-100">Договор / Shartnoma:</td>
                <td className="border border-black p-1.5 font-mono">
                  № {info.contractNumber}, {info.contractDate}
                </td>
                <td className="border border-black p-1.5 font-bold bg-slate-100">Заявка / Ariza:</td>
                <td className="border border-black p-1.5 font-mono">{info.applicationDate}</td>
              </tr>
              <tr>
                <td className="border border-black p-1.5 font-bold bg-slate-100">Объект калибровки:</td>
                <td className="border border-black p-1.5">{info.objectName}</td>
                <td className="border border-black p-1.5 font-bold bg-slate-100">Тип / Rusumi:</td>
                <td className="border border-black p-1.5 font-mono font-bold">{info.objectType}</td>
              </tr>
              <tr>
                <td className="border border-black p-1.5 font-bold bg-slate-100">Заводской номер:</td>
                <td className="border border-black p-1.5 font-mono">{info.serialNumber}</td>
                <td className="border border-black p-1.5 font-bold bg-slate-100">Разрешение шкафа:</td>
                <td className="border border-black p-1.5 font-mono">{formatMetrologyNumber(info.resolution, 2)} °C</td>
              </tr>
              <tr>
                <td className="border border-black p-1.5 font-bold bg-slate-100">Диапазон:</td>
                <td className="border border-black p-1.5 font-mono">
                  {info.tempRangeMin} ... {info.tempRangeMax} °C
                </td>
                <td className="border border-black p-1.5 font-bold bg-slate-100">Калибруемая точка:</td>
                <td className="border border-black p-1.5 font-mono font-bold">{calculation.pointTemp} °C</td>
              </tr>
              <tr>
                <td className="border border-black p-1.5 font-bold bg-slate-100">Эталонное оборудование:</td>
                <td className="border border-black p-1.5" colSpan={3}>
                  {info.standardName} ({info.standardType}), № {info.standardSerial}
                </td>
              </tr>
              <tr>
                <td className="border border-black p-1.5 font-bold bg-slate-100">Условия окружающей среды:</td>
                <td className="border border-black p-1.5" colSpan={3}>
                  Температура: {formatMetrologyNumber(info.ambientTempMin, 1)} ...{' '}
                  {formatMetrologyNumber(info.ambientTempMax, 1)} °С; Влажность:{' '}
                  {formatMetrologyNumber(info.relativeHumidityMin, 1)} ...{' '}
                  {formatMetrologyNumber(info.relativeHumidityMax, 1)} %
                </td>
              </tr>
            </tbody>
          </table>

          {/* 9 Points Summary Grid */}
          <div className="font-bold text-xs uppercase mb-1.5">
            Результаты измерений по 9 точкам рабочей камеры (Калибруемая точка: {calculation.pointTemp} °C):
          </div>

          <table className="w-full border-collapse border border-black text-center text-[10px] mb-3">
            <thead>
              <tr className="bg-slate-100 font-bold">
                <th className="border border-black p-1 w-8">№</th>
                {pointsData.map((pt) => (
                  <th key={pt.id} className="border border-black p-1" colSpan={2}>
                    {pt.id} {pt.isCenter ? '(Центр)' : ''}
                  </th>
                ))}
              </tr>
              <tr className="bg-slate-50 text-[9px]">
                <th className="border border-black p-0.5"></th>
                {pointsData.map((pt) => (
                  <React.Fragment key={pt.id}>
                    <th className="border border-black p-0.5">T_std</th>
                    <th className="border border-black p-0.5">T_ind</th>
                  </React.Fragment>
                ))}
              </tr>
            </thead>
            <tbody>
              {Array.from({ length: 10 }, (_, rowIdx) => (
                <tr key={rowIdx} className="font-mono">
                  <td className="border border-black p-0.5 font-bold bg-slate-50">{rowIdx + 1}</td>
                  {pointsData.map((pt) => {
                    const row = pt.rows[rowIdx];
                    return (
                      <React.Fragment key={pt.id}>
                        <td className="border border-black p-0.5">
                          {row && row.tStd !== '' ? formatMetrologyNumber(Number(row.tStd), 2) : '—'}
                        </td>
                        <td className="border border-black p-0.5">
                          {row && row.tInd !== '' ? formatMetrologyNumber(Number(row.tInd), 2) : '—'}
                        </td>
                      </React.Fragment>
                    );
                  })}
                </tr>
              ))}
            </tbody>
            <tfoot>
              <tr className="bg-slate-100 font-bold font-mono text-[9px]">
                <td className="border border-black p-1">Среднее:</td>
                {pointsData.map((pt) => {
                  const stat = calculation.pointStats[pt.id];
                  return (
                    <React.Fragment key={pt.id}>
                      <td className="border border-black p-0.5 text-blue-700">
                        {stat && stat.isEntered ? formatMetrologyNumber(stat.meanStd, 3) : '—'}
                      </td>
                      <td className="border border-black p-0.5">
                        {stat && stat.isEntered ? formatMetrologyNumber(stat.meanInd, 2) : '—'}
                      </td>
                    </React.Fragment>
                  );
                })}
              </tr>
            </tfoot>
          </table>

          {/* Key Parameters Box */}
          <div className="grid grid-cols-2 gap-3 border border-black p-2.5 mb-4 text-xs">
            <div>
              <span className="font-bold">Временная нестабильность (δT_instab): </span>
              <span className="font-mono font-bold">{formatMetrologyNumber(calculation.instabilityDelta, 4)} °C</span>
            </div>
            <div>
              <span className="font-bold">Пространственная неоднородность (δT_inhom): </span>
              <span className="font-mono font-bold">{formatMetrologyNumber(calculation.inhomogeneityDelta, 4)} °C</span>
            </div>
            <div>
              <span className="font-bold">Суммарная неопределенность (u_c): </span>
              <span className="font-mono font-bold">{formatMetrologyNumber(calculation.u_c, 5)} °C</span>
            </div>
            <div>
              <span className="font-bold">Расширенная неопределенность (U, k=2): </span>
              <span className="font-mono font-bold text-emerald-800">
                ±{formatMetrologyNumber(calculation.U, 2)} °C
              </span>
            </div>
          </div>

          {/* Signatures */}
          <div className="mt-6 pt-3 border-t border-black flex justify-between items-end text-xs">
            <div>
              <div className="font-bold">Лицо, выполнившее калибровку:</div>
              <div className="mt-1 font-bold underline">{info.calibratedByUz}</div>
              <div className="text-[10px] text-slate-600">{info.calibratedByRu}</div>
            </div>

            <div className="text-right">
              <div className="font-bold">Подпись: ______________________</div>
              <div className="text-[10px] text-slate-500 mt-1">Дата: {info.issueDate}</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
