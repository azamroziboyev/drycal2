import React, { useEffect, useRef, useState, useCallback } from 'react';
import * as THREE from 'three';
import { ChamberPointId, ChamberPointData } from '../types';
import { CHAMBER_POINTS_CONFIG } from '../utils/metrology';
import { RotateCw, CheckCircle2, CircleAlert, Eye, Maximize2 } from 'lucide-react';

interface ChamberCube3DProps {
  pointsData: ChamberPointData[];
  selectedPointId: ChamberPointId | null;
  onSelectPoint: (id: ChamberPointId) => void;
  className?: string;
}

export const ChamberCube3D: React.FC<ChamberCube3DProps> = ({
  pointsData,
  selectedPointId,
  onSelectPoint,
  className = '',
}) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const pointsGroupRef = useRef<THREE.Group | null>(null);
  const cubeMeshRef = useRef<THREE.Group | null>(null);
  const sphereMeshesRef = useRef<Map<ChamberPointId, THREE.Mesh>>(new Map());
  const haloMeshesRef = useRef<Map<ChamberPointId, THREE.Mesh>>(new Map());

  const [hoveredPoint, setHoveredPoint] = useState<ChamberPointId | null>(null);
  const [isAutoRotate, setIsAutoRotate] = useState(true);
  const isDraggingRef = useRef(false);
  const previousMousePositionRef = useRef({ x: 0, y: 0 });
  const rotationGroupRef = useRef<THREE.Group | null>(null);

  // Helper to determine if point has entered values
  const isPointEntered = useCallback((id: ChamberPointId) => {
    const pt = pointsData.find((p) => p.id === id);
    if (!pt) return false;
    return pt.rows.some((r) => r.tStd !== '' && !isNaN(Number(r.tStd)));
  }, [pointsData]);

  // Build / update 3D Scene
  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const width = container.clientWidth || 500;
    const height = container.clientHeight || 420;

    // 1. Scene
    const scene = new THREE.Scene();
    sceneRef.current = scene;

    // 2. Camera
    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 100);
    camera.position.set(3.8, 3.0, 4.8);
    camera.lookAt(0, 0, 0);
    cameraRef.current = camera;

    // 3. Renderer
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = false;
    rendererRef.current = renderer;

    // Clear previous children
    while (container.firstChild) {
      container.removeChild(container.firstChild);
    }
    container.appendChild(renderer.domElement);

    // 4. Lights
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.85);
    scene.add(ambientLight);

    const dirLight1 = new THREE.DirectionalLight(0xffffff, 1.2);
    dirLight1.position.set(5, 10, 7);
    scene.add(dirLight1);

    const dirLight2 = new THREE.DirectionalLight(0x93c5fd, 0.6);
    dirLight2.position.set(-5, -5, -5);
    scene.add(dirLight2);

    // 5. Root rotation group
    const rotGroup = new THREE.Group();
    scene.add(rotGroup);
    rotationGroupRef.current = rotGroup;

    // 6. Chamber Outer Frame & Cube
    const cubeGroup = new THREE.Group();
    rotGroup.add(cubeGroup);
    cubeMeshRef.current = cubeGroup;

    const boxSize = 2.4;
    // Glassy Chamber body
    const boxGeo = new THREE.BoxGeometry(boxSize, boxSize, boxSize);
    const boxMat = new THREE.MeshPhysicalMaterial({
      color: 0x38bdf8,
      transparent: true,
      opacity: 0.12,
      roughness: 0.2,
      metalness: 0.1,
      clearcoat: 0.8,
      side: THREE.DoubleSide,
      depthWrite: false,
    });
    const boxMesh = new THREE.Mesh(boxGeo, boxMat);
    cubeGroup.add(boxMesh);

    // Clean wireframe edges
    const edgesGeo = new THREE.EdgesGeometry(boxGeo);
    const edgesMat = new THREE.LineBasicMaterial({
      color: 0x0284c7,
      linewidth: 2,
      transparent: true,
      opacity: 0.75,
    });
    const wireframe = new THREE.LineSegments(edgesGeo, edgesMat);
    cubeGroup.add(wireframe);

    // Inner chamber grid / shelf plane (dashed lines to center N5)
    const corners = [
      new THREE.Vector3(-1.2, 1.2, 1.2),
      new THREE.Vector3(1.2, 1.2, 1.2),
      new THREE.Vector3(1.2, 1.2, -1.2),
      new THREE.Vector3(-1.2, 1.2, -1.2),
      new THREE.Vector3(-1.2, -1.2, 1.2),
      new THREE.Vector3(1.2, -1.2, 1.2),
      new THREE.Vector3(1.2, -1.2, -1.2),
      new THREE.Vector3(-1.2, -1.2, -1.2),
    ];
    const centerVec = new THREE.Vector3(0, 0, 0);

    const diagPoints: THREE.Vector3[] = [];
    corners.forEach((c) => {
      diagPoints.push(c);
      diagPoints.push(centerVec);
    });
    const diagGeo = new THREE.BufferGeometry().setFromPoints(diagPoints);
    const diagMat = new THREE.LineDashedMaterial({
      color: 0x94a3b8,
      dashSize: 0.1,
      gapSize: 0.08,
      transparent: true,
      opacity: 0.45,
    });
    const diagLines = new THREE.LineSegments(diagGeo, diagMat);
    diagLines.computeLineDistances();
    cubeGroup.add(diagLines);

    // 7. Measurement points (Spheres + Labels)
    const pointsGroup = new THREE.Group();
    rotGroup.add(pointsGroup);
    pointsGroupRef.current = pointsGroup;

    sphereMeshesRef.current.clear();
    haloMeshesRef.current.clear();

    CHAMBER_POINTS_CONFIG.forEach((pt) => {
      const entered = isPointEntered(pt.id);
      const isCenter = pt.isCenter;
      const isSelected = selectedPointId === pt.id;

      // Sphere geometry
      const radius = isCenter ? 0.22 : 0.17;
      const sphereGeo = new THREE.SphereGeometry(radius, 32, 32);

      // Sphere Material
      let baseColor = 0x64748b; // unentered slate
      let emissive = 0x0f172a;
      if (entered) {
        baseColor = 0x10b981; // emerald green
        emissive = 0x064e3b;
      }
      if (isSelected) {
        baseColor = 0x3b82f6; // blue/cyan for selected
        emissive = 0x1d4ed8;
      }

      const sphereMat = new THREE.MeshStandardMaterial({
        color: baseColor,
        emissive: emissive,
        roughness: 0.3,
        metalness: 0.4,
      });

      const sphere = new THREE.Mesh(sphereGeo, sphereMat);
      sphere.position.set(...pt.coord);
      sphere.userData = { id: pt.id, name: pt.nameUz, isCenter };
      pointsGroup.add(sphere);
      sphereMeshesRef.current.set(pt.id, sphere);

      // Outer Selection / Entered Halo
      const haloGeo = new THREE.RingGeometry(radius * 1.25, radius * 1.55, 32);
      const haloMat = new THREE.MeshBasicMaterial({
        color: isSelected ? 0x60a5fa : entered ? 0x34d399 : 0x94a3b8,
        side: THREE.DoubleSide,
        transparent: true,
        opacity: isSelected ? 0.9 : entered ? 0.6 : 0.25,
      });
      const halo = new THREE.Mesh(haloGeo, haloMat);
      halo.position.set(...pt.coord);
      halo.lookAt(camera.position);
      pointsGroup.add(halo);
      haloMeshesRef.current.set(pt.id, halo);

      // Text Sprite Label
      const canvas = document.createElement('canvas');
      canvas.width = 128;
      canvas.height = 64;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.fillStyle = entered ? 'rgba(16, 185, 129, 0.9)' : 'rgba(30, 41, 59, 0.85)';
        ctx.roundRect ? ctx.roundRect(10, 10, 108, 44, 8) : ctx.rect(10, 10, 108, 44);
        ctx.fill();
        ctx.strokeStyle = entered ? '#34d399' : '#64748b';
        ctx.lineWidth = 3;
        ctx.stroke();

        ctx.font = 'bold 24px Arial, sans-serif';
        ctx.fillStyle = '#ffffff';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(pt.id + (isCenter ? ' (M)' : ''), 64, 32);
      }
      const texture = new THREE.CanvasTexture(canvas);
      const spriteMat = new THREE.SpriteMaterial({ map: texture, transparent: true });
      const sprite = new THREE.Sprite(spriteMat);
      // Offset sprite slightly above the point
      sprite.position.set(pt.coord[0], pt.coord[1] + (isCenter ? 0.38 : 0.32), pt.coord[2]);
      sprite.scale.set(0.65, 0.32, 1);
      pointsGroup.add(sprite);
    });

    // 8. Animation loop
    let animationFrameId: number;
    let clock = new THREE.Clock();

    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);
      const delta = clock.getDelta();

      if (isAutoRotate && !isDraggingRef.current && rotGroup) {
        rotGroup.rotation.y += delta * 0.45;
      }

      // Halos should always billboard face camera
      haloMeshesRef.current.forEach((halo) => {
        halo.lookAt(camera.position);
      });

      renderer.render(scene, camera);
    };

    animate();

    // 9. Resize observer
    const handleResize = () => {
      if (!container || !rendererRef.current || !cameraRef.current) return;
      const w = container.clientWidth || 500;
      const h = container.clientHeight || 420;
      cameraRef.current.aspect = w / h;
      cameraRef.current.updateProjectionMatrix();
      rendererRef.current.setSize(w, h);
    };

    const resizeObserver = new ResizeObserver(handleResize);
    resizeObserver.observe(container);

    // Cleanup
    return () => {
      cancelAnimationFrame(animationFrameId);
      resizeObserver.disconnect();
      renderer.dispose();
      while (container.firstChild) {
        container.removeChild(container.firstChild);
      }
    };
  }, [pointsData, selectedPointId, isPointEntered]);

  // Update point sphere colors dynamically when data changes or point selected
  useEffect(() => {
    sphereMeshesRef.current.forEach((mesh, id) => {
      const entered = isPointEntered(id);
      const isSelected = selectedPointId === id;
      const mat = mesh.material as THREE.MeshStandardMaterial;

      if (isSelected) {
        mat.color.setHex(0x2563eb); // Primary blue
        mat.emissive.setHex(0x1d4ed8);
      } else if (entered) {
        mat.color.setHex(0x10b981); // Emerald green
        mat.emissive.setHex(0x065f46);
      } else {
        mat.color.setHex(0x64748b); // Slate
        mat.emissive.setHex(0x1e293b);
      }
    });

    haloMeshesRef.current.forEach((halo, id) => {
      const entered = isPointEntered(id);
      const isSelected = selectedPointId === id;
      const mat = halo.material as THREE.MeshBasicMaterial;

      if (isSelected) {
        mat.color.setHex(0x60a5fa);
        mat.opacity = 0.9;
      } else if (entered) {
        mat.color.setHex(0x34d399);
        mat.opacity = 0.7;
      } else {
        mat.color.setHex(0x94a3b8);
        mat.opacity = 0.25;
      }
    });
  }, [selectedPointId, pointsData, isPointEntered]);

  // Mouse / Touch Drag Rotation & Raycasting for Point Click
  const handleMouseDown = (e: React.MouseEvent<HTMLDivElement>) => {
    isDraggingRef.current = true;
    previousMousePositionRef.current = { x: e.clientX, y: e.clientY };
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const container = mountRef.current;
    if (!container || !cameraRef.current || !sceneRef.current) return;

    if (isDraggingRef.current) {
      const deltaX = e.clientX - previousMousePositionRef.current.x;
      const deltaY = e.clientY - previousMousePositionRef.current.y;

      if (rotationGroupRef.current) {
        rotationGroupRef.current.rotation.y += deltaX * 0.012;
        rotationGroupRef.current.rotation.x += deltaY * 0.012;
      }

      previousMousePositionRef.current = { x: e.clientX, y: e.clientY };
      return;
    }

    // Raycast for hover
    const rect = container.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    const y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

    const raycaster = new THREE.Raycaster();
    raycaster.setFromCamera(new THREE.Vector2(x, y), cameraRef.current);

    const spheres = Array.from(sphereMeshesRef.current.values());
    const intersects = raycaster.intersectObjects(spheres, false);

    if (intersects.length > 0) {
      const id = intersects[0].object.userData.id as ChamberPointId;
      setHoveredPoint(id);
      container.style.cursor = 'pointer';
    } else {
      setHoveredPoint(null);
      container.style.cursor = 'grab';
    }
  };

  const handleMouseUp = (e: React.MouseEvent<HTMLDivElement>) => {
    const container = mountRef.current;
    if (!container || !cameraRef.current) {
      isDraggingRef.current = false;
      return;
    }

    // If it was just a click (not a drag), trigger point selection
    const dx = Math.abs(e.clientX - previousMousePositionRef.current.x);
    const dy = Math.abs(e.clientY - previousMousePositionRef.current.y);

    if (dx < 5 && dy < 5) {
      const rect = container.getBoundingClientRect();
      const x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      const y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

      const raycaster = new THREE.Raycaster();
      raycaster.setFromCamera(new THREE.Vector2(x, y), cameraRef.current);

      const spheres = Array.from(sphereMeshesRef.current.values());
      const intersects = raycaster.intersectObjects(spheres, false);

      if (intersects.length > 0) {
        const id = intersects[0].object.userData.id as ChamberPointId;
        onSelectPoint(id);
      }
    }

    isDraggingRef.current = false;
  };

  // Reset orientation
  const resetOrientation = () => {
    if (rotationGroupRef.current) {
      rotationGroupRef.current.rotation.set(0, 0, 0);
    }
  };

  // Stats calculation for display
  const enteredCount = pointsData.filter((p) =>
    p.rows.some((r) => r.tStd !== '' && !isNaN(Number(r.tStd)))
  ).length;

  const activeHoverPointData = hoveredPoint
    ? CHAMBER_POINTS_CONFIG.find((p) => p.id === hoveredPoint)
    : null;

  return (
    <div className={`relative flex flex-col rounded-2xl bg-slate-900 border border-slate-800 text-white shadow-xl overflow-hidden ${className}`}>
      {/* Header bar */}
      <div className="flex items-center justify-between px-4 py-3 bg-slate-950/70 border-b border-slate-800/80 backdrop-blur-sm z-10">
        <div className="flex items-center space-x-2">
          <div className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
          <span className="font-semibold text-sm tracking-wide text-slate-200">
            Quritish Shkafi 3D Geometriyasi (9 Nuqta)
          </span>
          <span className="text-xs px-2 py-0.5 rounded-full bg-slate-800 border border-slate-700 text-slate-300 font-mono">
            {enteredCount}/9 to'ldirildi
          </span>
        </div>

        <div className="flex items-center space-x-2">
          <button
            type="button"
            onClick={() => setIsAutoRotate(!isAutoRotate)}
            title={isAutoRotate ? 'Aylanishni toʻxtatish' : 'Avtomatik aylanish'}
            className={`px-2.5 py-1 text-xs rounded-lg border flex items-center space-x-1.5 transition-all ${
              isAutoRotate
                ? 'bg-blue-600/30 border-blue-500/50 text-blue-200'
                : 'bg-slate-800/80 border-slate-700 text-slate-400 hover:text-slate-200'
            }`}
          >
            <RotateCw className={`w-3.5 h-3.5 ${isAutoRotate ? 'animate-spin' : ''}`} style={{ animationDuration: '6s' }} />
            <span>{isAutoRotate ? 'Aylanmoqda' : 'Toʻxtatilgan'}</span>
          </button>

          <button
            type="button"
            onClick={resetOrientation}
            title="Qayta tiklash"
            className="p-1.5 rounded-lg bg-slate-800/80 border border-slate-700 text-slate-400 hover:text-white hover:bg-slate-700 transition"
          >
            <Maximize2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* 3D Canvas Mount */}
      <div
        ref={mountRef}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        className="w-full h-[380px] sm:h-[420px] cursor-grab active:cursor-grabbing relative select-none"
      />

      {/* Floating Hover Tooltip */}
      {activeHoverPointData && (
        <div className="absolute top-14 left-4 z-20 pointer-events-none bg-slate-950/90 border border-slate-700/80 rounded-xl px-3.5 py-2 shadow-2xl backdrop-blur-md max-w-xs transition-all">
          <div className="flex items-center space-x-2">
            <span
              className={`w-2.5 h-2.5 rounded-full ${
                isPointEntered(activeHoverPointData.id) ? 'bg-emerald-400' : 'bg-slate-400'
              }`}
            />
            <span className="font-bold text-sm text-white">
              {activeHoverPointData.id} - {activeHoverPointData.nameUz}
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">{activeHoverPointData.positionDesc}</p>
          <div className="mt-1.5 text-[11px] font-mono text-emerald-300">
            {isPointEntered(activeHoverPointData.id) ? (
              <span className="flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 inline" /> Qiymatlar kiritilgan (Yashil)
              </span>
            ) : (
              <span className="flex items-center gap-1 text-slate-400">
                <CircleAlert className="w-3.5 h-3.5 text-slate-400 inline" /> Kiritish uchun ustiga bosing
              </span>
            )}
          </div>
        </div>
      )}

      {/* Bottom helper & 9-Points quick buttons */}
      <div className="p-3 bg-slate-950/80 border-t border-slate-800/80 backdrop-blur-sm z-10 flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center space-x-2 text-xs text-slate-400">
          <span className="flex items-center gap-1">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 inline-block" /> Yashil = Kiritilgan
          </span>
          <span className="flex items-center gap-1">
            <span className="w-2.5 h-2.5 rounded-full bg-slate-500 inline-block" /> Kulrang = Kiritilmagan
          </span>
          <span className="flex items-center gap-1">
            <span className="w-2.5 h-2.5 rounded-full bg-blue-500 inline-block" /> Ko'k = Tanlangan
          </span>
        </div>

        {/* Quick point select chips */}
        <div className="flex items-center gap-1 overflow-x-auto py-0.5">
          {CHAMBER_POINTS_CONFIG.map((pt) => {
            const entered = isPointEntered(pt.id);
            const isSelected = selectedPointId === pt.id;
            return (
              <button
                key={pt.id}
                type="button"
                onClick={() => onSelectPoint(pt.id)}
                className={`px-2 py-1 rounded-md text-xs font-semibold font-mono transition-all ${
                  isSelected
                    ? 'bg-blue-600 text-white ring-2 ring-blue-400'
                    : entered
                    ? 'bg-emerald-600/30 text-emerald-300 border border-emerald-500/50 hover:bg-emerald-600/50'
                    : 'bg-slate-800 text-slate-400 border border-slate-700 hover:bg-slate-700 hover:text-slate-200'
                }`}
                title={`${pt.id}: ${pt.nameUz}`}
              >
                {pt.id}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
