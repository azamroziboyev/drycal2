import React from 'react';
import { UZNIM_LOGO_BASE64, UZNIM_LOGO_SRC } from '../assets/logo';

export const UzNimLogo: React.FC<{ 
  className?: string; 
  size?: number;
  width?: number;
  height?: number;
}> = ({ 
  className = '', 
  size = 52,
  width,
  height,
}) => {
  // Original logo dimensions: 107 x 76 (aspect ratio ~ 1.408)
  const calculatedHeight = height || size;
  const calculatedWidth = width || Math.round(calculatedHeight * 1.408);

  return (
    <img 
      src={UZNIM_LOGO_BASE64 || UZNIM_LOGO_SRC}
      alt="O‘zbekiston Milliy Metrologiya Instituti logotipi"
      width={calculatedWidth}
      height={calculatedHeight}
      className={`inline-block object-contain select-none ${className}`}
      style={{
        height: `${calculatedHeight}px`,
        width: `${calculatedWidth}px`,
        maxWidth: '100%',
      }}
      loading="eager"
      decoding="sync"
    />
  );
};

export const QrCodeSvg: React.FC<{ size?: number; text?: string; className?: string }> = ({ 
  size = 72, 
  text = 'e-metrologiya.uz/cert/UZ-0000-2026', 
  className = '' 
}) => {
  return (
    <div className={`flex flex-col items-center justify-center p-1 bg-white border border-slate-300 rounded ${className}`}>
      <svg width={size} height={size} viewBox="0 0 100 100" fill="black">
        {/* Simple crisp QR code vector representation */}
        <rect width="100" height="100" fill="white" />
        {/* Corner 1 */}
        <rect x="6" y="6" width="28" height="28" fill="black" />
        <rect x="10" y="10" width="20" height="20" fill="white" />
        <rect x="14" y="14" width="12" height="12" fill="black" />
        
        {/* Corner 2 */}
        <rect x="66" y="6" width="28" height="28" fill="black" />
        <rect x="70" y="10" width="20" height="20" fill="white" />
        <rect x="74" y="14" width="12" height="12" fill="black" />
        
        {/* Corner 3 */}
        <rect x="6" y="66" width="28" height="28" fill="black" />
        <rect x="10" y="70" width="20" height="20" fill="white" />
        <rect x="14" y="74" width="12" height="12" fill="black" />
        
        {/* Data modules */}
        <rect x="42" y="8" width="6" height="6" fill="black" />
        <rect x="52" y="8" width="6" height="12" fill="black" />
        <rect x="40" y="22" width="18" height="6" fill="black" />
        <rect x="44" y="34" width="12" height="6" fill="black" />
        <rect x="8" y="42" width="6" height="18" fill="black" />
        <rect x="20" y="42" width="12" height="6" fill="black" />
        <rect x="22" y="52" width="8" height="8" fill="black" />
        <rect x="40" y="46" width="8" height="8" fill="black" />
        <rect x="54" y="44" width="14" height="6" fill="black" />
        <rect x="74" y="42" width="18" height="6" fill="black" />
        <rect x="68" y="54" width="10" height="8" fill="black" />
        <rect x="84" y="54" width="8" height="16" fill="black" />
        <rect x="42" y="62" width="8" height="14" fill="black" />
        <rect x="54" y="60" width="10" height="10" fill="black" />
        <rect x="40" y="82" width="16" height="10" fill="black" />
        <rect x="62" y="78" width="10" height="14" fill="black" />
        <rect x="78" y="78" width="14" height="14" fill="black" />
      </svg>
      <span className="text-[7px] text-slate-500 font-mono mt-0.5 tracking-tight truncate max-w-[80px]">
        {text}
      </span>
    </div>
  );
};
