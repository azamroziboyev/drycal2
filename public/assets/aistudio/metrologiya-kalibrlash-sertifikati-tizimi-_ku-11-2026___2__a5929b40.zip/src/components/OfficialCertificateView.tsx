import React, { useState } from 'react';
import { CalibrationItemInfo, ChamberCalculation, ChamberPointData } from '../types';
import { formatMetrologyNumber } from '../utils/metrology';
import { UzNimLogo, QrCodeSvg } from './UzNimLogo';
import { downloadElementAsPdf, printCertificatePages } from '../utils/pdfGenerator';
import { Download, Printer, CheckCircle, ArrowLeft, Loader2, AlertCircle } from 'lucide-react';

interface OfficialCertificateViewProps {
  info: CalibrationItemInfo;
  calculation: ChamberCalculation;
  pointsData: ChamberPointData[];
  onBackToEdit: () => void;
  onSaveCertificate: () => void;
}

export const OfficialCertificateView: React.FC<OfficialCertificateViewProps> = ({
  info,
  calculation,
  pointsData,
  onBackToEdit,
  onSaveCertificate,
}) => {
  const [currentPage, setCurrentPage] = useState<number | 'all'>('all');
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);
  const [pdfProgress, setPdfProgress] = useState<{ percent: number; status: string }>({
    percent: 0,
    status: '',
  });
  const [downloadSuccess, setDownloadSuccess] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string>('');

  const handleDownloadPdf = async () => {
    setIsGeneratingPdf(true);
    setDownloadSuccess(false);
    setErrorMessage('');

    onSaveCertificate();

    try {
      const pageIds = ['cert-page-1', 'cert-page-2', 'cert-page-3', 'cert-page-4'];
      const cleanFileName = `Sertifikat_${info.certificateNumber.replace(/[\/\\]/g, '_')}_${info.serialNumber}.pdf`;

      await downloadElementAsPdf(pageIds, cleanFileName, (percent, status) => {
        setPdfProgress({ percent, status });
      });

      setDownloadSuccess(true);
      setTimeout(() => setDownloadSuccess(false), 4000);
    } catch (err: any) {
      console.error('PDF generation error', err);
      setErrorMessage(
        'Sertifikatni yuklab olishda muammo yuz berdi. "Chop etish" tugmasi orqali to‘g‘ridan-to‘g‘ri PDF sifatida saqlashingiz mumkin.'
      );
    } finally {
      setIsGeneratingPdf(false);
    }
  };

  const handlePrint = () => {
    onSaveCertificate();
    const pageIds = ['cert-page-1', 'cert-page-2', 'cert-page-3', 'cert-page-4'];
    printCertificatePages(pageIds);
  };

  const pointTemp = calculation.pointTemp;
  const refValue = calculation.centerStdMean;
  const indValue = calculation.centerIndMean;
  const devValue = Math.abs(calculation.deviation);
  const extUncertainty = calculation.U;
  const inhomValue = calculation.inhomogeneityDelta;
  const instabValue = calculation.instabilityDelta;

  return (
    <div className="space-y-6">
      {/* Top Controls Bar */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4 print:hidden">
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={onBackToEdit}
            className="p-2 rounded-xl text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
            title="Tahrirlashga qaytish"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <span>Rasmiy Kalibrlash Sertifikati (4 sahifa)</span>
              <span className="text-xs px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 font-mono">
                {info.certificateNumber}
              </span>
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Quritish shkafi / Harorat kamerasi (DIN EN 60068-3-5 / EURAMET cg-20)
            </p>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Page Selector */}
          <div className="inline-flex rounded-lg border border-slate-200 dark:border-slate-700 p-0.5 bg-slate-50 dark:bg-slate-800 text-xs">
            <button
              onClick={() => setCurrentPage('all')}
              className={`px-2.5 py-1 rounded-md font-medium cursor-pointer ${
                currentPage === 'all'
                  ? 'bg-white dark:bg-slate-900 text-blue-600 shadow-xs'
                  : 'text-slate-600 dark:text-slate-300'
              }`}
            >
              Barchasi (1-4)
            </button>
            <button
              onClick={() => setCurrentPage(1)}
              className={`px-2 py-1 rounded-md font-medium cursor-pointer ${
                currentPage === 1
                  ? 'bg-white dark:bg-slate-900 text-blue-600 shadow-xs'
                  : 'text-slate-600 dark:text-slate-300'
              }`}
            >
              1-bet
            </button>
            <button
              onClick={() => setCurrentPage(2)}
              className={`px-2 py-1 rounded-md font-medium cursor-pointer ${
                currentPage === 2
                  ? 'bg-white dark:bg-slate-900 text-blue-600 shadow-xs'
                  : 'text-slate-600 dark:text-slate-300'
              }`}
            >
              2-bet
            </button>
            <button
              onClick={() => setCurrentPage(3)}
              className={`px-2 py-1 rounded-md font-medium cursor-pointer ${
                currentPage === 3
                  ? 'bg-white dark:bg-slate-900 text-blue-600 shadow-xs'
                  : 'text-slate-600 dark:text-slate-300'
              }`}
            >
              3-bet
            </button>
            <button
              onClick={() => setCurrentPage(4)}
              className={`px-2 py-1 rounded-md font-medium cursor-pointer ${
                currentPage === 4
                  ? 'bg-white dark:bg-slate-900 text-blue-600 shadow-xs'
                  : 'text-slate-600 dark:text-slate-300'
              }`}
            >
              4-bet
            </button>
          </div>

          <button
            type="button"
            onClick={handlePrint}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 transition-colors cursor-pointer"
          >
            <Printer className="w-4 h-4 text-slate-500" />
            <span>Chop etish</span>
          </button>

          <button
            type="button"
            disabled={isGeneratingPdf}
            onClick={handleDownloadPdf}
            className="flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold bg-blue-600 hover:bg-blue-700 text-white shadow-sm shadow-blue-500/20 disabled:opacity-60 transition-all cursor-pointer"
          >
            {isGeneratingPdf ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>
                  {pdfProgress.percent}% ({pdfProgress.status})
                </span>
              </>
            ) : (
              <>
                <Download className="w-4 h-4" />
                <span>Sertifikatni yuklab olish</span>
              </>
            )}
          </button>
        </div>
      </div>

      {downloadSuccess && (
        <div className="p-3 bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-900 rounded-xl text-xs text-emerald-800 dark:text-emerald-300 flex items-center gap-2 print:hidden">
          <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>Sertifikat PDF formati muvaffaqiyatli saqlandi va yuklab olindi!</span>
        </div>
      )}

      {errorMessage && (
        <div className="p-3 bg-red-50 dark:bg-red-950/50 border border-red-200 dark:border-red-900 rounded-xl text-xs text-red-700 dark:text-red-300 flex items-center gap-2 print:hidden">
          <AlertCircle className="w-4 h-4 text-red-500 shrink-0" />
          <span>{errorMessage}</span>
        </div>
      )}

      {/* Pages Container */}
      <div className="flex flex-col items-center gap-8 py-4 bg-slate-200 dark:bg-slate-950 p-4 rounded-2xl overflow-x-auto">
        {/* ==================== PAGE 1 ==================== */}
        <div
          id="cert-page-1"
          className={`w-[210mm] min-h-[297mm] h-[297mm] p-[16mm] bg-white text-black shadow-2xl relative font-sans text-[11px] leading-snug flex-col justify-between box-border shrink-0 print:shadow-none print:m-0 print:p-[12mm] ${
            currentPage === 'all' || currentPage === 1 ? 'flex' : 'hidden print:flex'
          }`}
          style={{ fontFamily: 'Arial, sans-serif' }}
        >
          <div>
            {/* Header */}
            <div className="flex items-start justify-between border-b-2 border-transparent pb-2">
              <div className="w-24 shrink-0 flex items-center justify-start">
                <UzNimLogo size={56} />
              </div>

              <div className="flex-1 text-center px-2">
                <h1 className="text-sm font-bold tracking-tight text-slate-900 uppercase">
                  O‘ZBEKISTON MILLIY METROLOGIYA INSTITUTI
                </h1>
                <h2 className="text-xs font-bold tracking-tight text-slate-800 uppercase mt-0.5">
                  UZBEK NATIONAL INSTITUTE OF METROLOGY
                </h2>
              </div>

              {/* Top Right Accreditation Box */}
              <div className="border border-black p-1 text-center text-[10px] w-24 shrink-0 font-bold leading-tight">
                <div className="border-b border-black pb-0.5">Z/0000-</div>
                <div className="py-0.5 text-[9px]">
                  OʻZAK.
                  <br />
                  KL.0013
                </div>
                <div className="border-t border-black pt-0.5 text-[9px]">{info.issueDate}</div>
              </div>
            </div>

            {/* Title */}
            <div className="text-center my-6">
              <h2 className="text-lg font-bold text-black uppercase">Сертификат калибровки</h2>
              <h3 className="text-sm italic font-medium text-slate-700 mt-0.5">
                Calibration certificate
              </h3>
            </div>

            {/* General Metadata Grid */}
            <div className="grid grid-cols-3 gap-2 border-b border-black pb-3 text-xs">
              <div>
                <div className="font-bold">Дата выдачи:</div>
                <div className="italic text-[10px] text-slate-600">Date of issue:</div>
                <div className="mt-1 font-mono">{info.issueDate}</div>
              </div>
              <div>
                <div className="font-bold">Номер сертификата:</div>
                <div className="italic text-[10px] text-slate-600">Certificate number:</div>
                <div className="mt-1 font-mono font-bold">{info.certificateNumber}</div>
              </div>
              <div>
                <div className="font-bold">Количество страниц:</div>
                <div className="italic text-[10px] text-slate-600">Number of pages:</div>
                <div className="mt-1 font-mono">4</div>
              </div>
            </div>

            {/* Items Details List */}
            <div className="space-y-4 my-6 text-xs">
              <div className="grid grid-cols-12 gap-2">
                <div className="col-span-5 font-bold">
                  Объект калибровки:
                  <br />
                  <span className="italic font-normal text-[10px] text-slate-600">
                    Calibration item:
                  </span>
                </div>
                <div className="col-span-7 font-medium">{info.objectName}</div>
              </div>

              <div className="grid grid-cols-12 gap-2">
                <div className="col-span-5 font-bold">
                  Производитель:
                  <br />
                  <span className="italic font-normal text-[10px] text-slate-600">
                    Manufacturer:
                  </span>
                </div>
                <div className="col-span-7 font-medium">{info.manufacturer}</div>
              </div>

              <div className="grid grid-cols-12 gap-2">
                <div className="col-span-5 font-bold">
                  Тип (модель, серия):
                  <br />
                  <span className="italic font-normal text-[10px] text-slate-600">
                    Type (model, series):
                  </span>
                </div>
                <div className="col-span-7 font-medium">{info.objectType}</div>
              </div>

              <div className="grid grid-cols-12 gap-2">
                <div className="col-span-5 font-bold">
                  Серийный номер:
                  <br />
                  <span className="italic font-normal text-[10px] text-slate-600">
                    Serial number:
                  </span>
                </div>
                <div className="col-span-7 font-mono font-bold">{info.serialNumber}</div>
              </div>

              <div className="grid grid-cols-12 gap-2">
                <div className="col-span-5 font-bold">
                  Заказчик:
                  <br />
                  <span className="italic font-normal text-[10px] text-slate-600">Customer:</span>
                </div>
                <div className="col-span-7 font-medium">{info.customerName}</div>
              </div>
            </div>

            {/* Bottom Notice & Signatures */}
            <div className="mt-14 space-y-6">
              <div className="grid grid-cols-12 gap-4 items-center">
                {/* Warning Red Box */}
                <div className="col-span-5 border border-red-500 p-2.5 text-[9px] text-red-700 leading-snug">
                  <p className="font-bold">
                    Сертификат калибровки рассматривается как недействительный без сгенерированного системой e-metrologiya.uz листа, содержащего ссылку на него
                  </p>
                  <p className="italic text-slate-600 mt-1">
                    The calibration certificate is considered invalid without a sheet generated by the e-metrologiya.uz system containing a link to it
                  </p>
                </div>

                {/* Signatures */}
                <div className="col-span-7 space-y-4 text-xs">
                  <div>
                    <div className="font-bold">Калибровку выполнил:</div>
                    <div className="italic text-[10px] text-slate-600">
                      Calibration performed by:
                    </div>
                    <div className="mt-1 font-semibold text-slate-900 border-b border-black pb-0.5 inline-block min-w-[200px]">
                      {info.calibratedByUz}
                      <span className="block text-[10px] text-slate-600 font-normal">
                        {info.calibratedByRu}
                      </span>
                    </div>
                  </div>

                  <div>
                    <div className="font-bold">Проверил:</div>
                    <div className="italic text-[10px] text-slate-600">Checked by:</div>
                    <div className="mt-1 font-semibold text-slate-900 border-b border-black pb-0.5 inline-block min-w-[200px]">
                      {info.checkedByUz}
                      <span className="block text-[10px] text-slate-600 font-normal">
                        {info.checkedByRu}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Reproduction box */}
              <div className="border border-black p-2 text-center text-[10px]">
                <p className="font-bold">
                  Сертификат калибровки не может быть воспроизведен, кроме как в полном объеме
                </p>
                <p className="italic text-slate-600">
                  Calibration certificate shall not be reproduced except in full
                </p>
              </div>
            </div>
          </div>

          {/* Official Footer */}
          <div className="border-t border-black pt-2 text-[8px] text-slate-700 flex justify-between items-center">
            <div>
              <span className="font-bold">F.G104.C</span>
              <br />
              (2025-10-27)
            </div>
            <div className="text-center flex-1 px-4 leading-tight">
              Узбекистан, 100174, Ташкент, Алмазарский район, улица Фаробий, 333 А, 333 Б www.nim.uz
              <br />
              333 A, 333 B, Farobiy street, Almazar district, Tashkent, 100174, Uzbekistan www.nim.uz
            </div>
          </div>
        </div>

        {/* ==================== PAGE 2 ==================== */}
        <div
          id="cert-page-2"
          className={`w-[210mm] min-h-[297mm] h-[297mm] p-[16mm] bg-white text-black shadow-2xl relative font-sans text-[11px] leading-snug flex-col justify-between box-border shrink-0 print:shadow-none print:m-0 print:p-[12mm] ${
            currentPage === 'all' || currentPage === 2 ? 'flex' : 'hidden print:flex'
          }`}
          style={{ fontFamily: 'Arial, sans-serif' }}
        >
          <div>
            {/* Header */}
            <div className="flex items-start justify-between border-b border-black pb-2 text-[10px]">
              <div>
                <div className="font-bold uppercase">УЗБЕКСКИЙ НАЦИОНАЛЬНЫЙ ИНСТИТУТ МЕТРОЛОГИИ</div>
                <div className="italic text-slate-700 uppercase">
                  UZBEK NATIONAL INSTITUTE OF METROLOGY
                </div>
              </div>
              <div className="border border-black px-2 py-0.5 text-center font-bold">
                <div>Z/0000-</div>
                <div className="text-[8px]">OʻZAK. KL.0013</div>
              </div>
            </div>

            {/* Sub-header meta */}
            <div className="flex justify-between items-center py-2 text-xs border-b border-slate-300">
              <div>
                <span className="font-bold">Номер сертификата: </span>
                <span className="font-mono font-bold underline">{info.certificateNumber}</span>
                <div className="italic text-[9px] text-slate-600">Certificate number:</div>
              </div>
              <div>
                <span className="font-bold">Страница: </span>
                <span className="font-mono font-bold">2</span>
                <div className="italic text-[9px] text-slate-600">Page:</div>
              </div>
              <div className="font-mono font-bold text-xs">{info.issueDate}</div>
            </div>

            {/* Content items */}
            <div className="space-y-4 my-4 text-xs">
              <div>
                <span className="font-bold">Запрос на калибровку: </span> {info.issueDate} №
                <div className="italic text-[10px] text-slate-600">Calibration request:</div>
              </div>

              <div>
                <span className="font-bold">Период калибровки: </span> {info.calibrationPeriod}
                <div className="italic text-[10px] text-slate-600">Calibration period:</div>
              </div>

              <div>
                <div className="font-bold">Наименование лаборатории:</div>
                <div className="italic text-[10px] text-slate-600">Name of laboratory:</div>
                <div className="mt-1 font-medium leading-tight">
                  {info.laboratoryNameRu}
                  <div className="italic text-slate-600 text-[10px] mt-0.5">
                    {info.laboratoryNameEn}
                  </div>
                </div>
              </div>

              <div>
                <div className="font-bold">Место осуществления измерений:</div>
                <div className="italic text-[10px] text-slate-600">
                  Location of performance of measurement:
                </div>
                <div className="mt-0.5 text-slate-700">Стационарная калибровочная лаборатория</div>
              </div>

              {/* Environmental Conditions */}
              <div className="mt-4">
                <div className="font-bold">Условия калибровки:</div>
                <div className="italic text-[10px] text-slate-600 mb-2">
                  Calibration conditions:
                </div>

                <table className="w-full border-collapse border border-black text-xs text-center">
                  <thead>
                    <tr className="bg-slate-100 font-bold">
                      <th className="border border-black p-1.5" colSpan={2}>
                        Условия окружающей среды
                        <br />
                        <span className="italic font-normal text-[10px]">
                          Environmental conditions
                        </span>
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td className="border border-black p-2 text-left">
                        <span className="font-bold">температура окружающего воздуха</span>
                        <br />
                        <span className="italic text-[10px] text-slate-600">
                          ambient temperature
                        </span>
                      </td>
                      <td className="border border-black p-2 font-mono">
                        ({formatMetrologyNumber(info.ambientTempMin, 1)} ±{' '}
                        {formatMetrologyNumber(info.ambientTempMax - info.ambientTempMin, 1)}) °С
                      </td>
                    </tr>
                    <tr>
                      <td className="border border-black p-2 text-left">
                        <span className="font-bold">относительная влажность</span>
                        <br />
                        <span className="italic text-[10px] text-slate-600">relative humidity</span>
                      </td>
                      <td className="border border-black p-2 font-mono">
                        (от {formatMetrologyNumber(info.relativeHumidityMin, 0)} до{' '}
                        {formatMetrologyNumber(info.relativeHumidityMax, 0)}) %
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>

              {/* Method */}
              <div className="mt-4">
                <div className="font-bold">Метод и калибровочная процедура:</div>
                <div className="italic text-[10px] text-slate-600">
                  Method and calibration procedure:
                </div>
                <div className="mt-1 font-bold">
                  EURAMET Calibration Guide-20 Version 5.0 (DIN EN 60068-3-5)
                  <br />
                  ПРОЦЕДУРА КАЛИБРОВКИ: Сушильные шкафы и температурные камеры
                </div>
              </div>

              {/* Standards Table */}
              <div className="mt-4">
                <div className="font-bold">Калибровка выполнена с помощью:</div>
                <div className="italic text-[10px] text-slate-600 mb-2">
                  Calibration is performed by using:
                </div>

                <table className="w-full border-collapse border border-black text-xs text-center">
                  <thead>
                    <tr className="bg-slate-100 font-bold">
                      <th className="border border-black p-1.5 w-8">№</th>
                      <th className="border border-black p-1.5">
                        Опорный измерительный эталон
                        <br />
                        <span className="italic font-normal text-[9px]">
                          Reference measurement standard
                        </span>
                      </th>
                      <th className="border border-black p-1.5">
                        Тип / Модель
                        <br />
                        <span className="italic font-normal text-[9px]">Type / Model</span>
                      </th>
                      <th className="border border-black p-1.5">
                        Серийный номер
                        <br />
                        <span className="italic font-normal text-[9px]">Serial Number</span>
                      </th>
                      <th className="border border-black p-1.5">
                        Метрологическая прослеживаемость
                        <br />
                        <span className="italic font-normal text-[9px]">
                          Metrological traceability
                        </span>
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td className="border border-black p-2 font-mono">1</td>
                      <td className="border border-black p-2 font-medium">{info.standardName}</td>
                      <td className="border border-black p-2 font-mono">{info.standardType}</td>
                      <td className="border border-black p-2 font-mono">{info.standardSerial}</td>
                      <td className="border border-black p-2 font-mono text-[10px]">
                        {info.standardTraceability}
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          {/* Official Footer */}
          <div className="border-t border-black pt-2 text-[8px] text-slate-700 flex justify-between items-center">
            <div>
              <span className="font-bold">F.G104.C</span>
              <br />
              (2025-10-27)
            </div>
            <div className="text-center flex-1 px-4 leading-tight">
              Узбекистан, 100174, Ташкент, Алмазарский район, улица Фаробий, 333 А, 333 Б www.nim.uz
              <br />
              333 A, 333 B, Farobiy street, Almazar district, Tashkent, 100174, Uzbekistan www.nim.uz
            </div>
          </div>
        </div>

        {/* ==================== PAGE 3 ==================== */}
        <div
          id="cert-page-3"
          className={`w-[210mm] min-h-[297mm] h-[297mm] p-[16mm] bg-white text-black shadow-2xl relative font-sans text-[11px] leading-snug flex-col justify-between box-border shrink-0 print:shadow-none print:m-0 print:p-[12mm] ${
            currentPage === 'all' || currentPage === 3 ? 'flex' : 'hidden print:flex'
          }`}
          style={{ fontFamily: 'Arial, sans-serif' }}
        >
          <div>
            {/* Header */}
            <div className="flex items-start justify-between border-b border-black pb-2 text-[10px]">
              <div>
                <div className="font-bold uppercase">УЗБЕКСКИЙ НАЦИОНАЛЬНЫЙ ИНСТИТУТ МЕТРОЛОГИИ</div>
                <div className="italic text-slate-700 uppercase">
                  UZBEK NATIONAL INSTITUTE OF METROLOGY
                </div>
              </div>
              <div className="border border-black px-2 py-0.5 text-center font-bold">
                <div>Z/0000-</div>
                <div className="text-[8px]">OʻZAK. KL.0013</div>
              </div>
            </div>

            {/* Sub-header meta */}
            <div className="flex justify-between items-center py-2 text-xs border-b border-slate-300">
              <div>
                <span className="font-bold">Номер сертификата: </span>
                <span className="font-mono font-bold underline">{info.certificateNumber}</span>
                <div className="italic text-[9px] text-slate-600">Certificate number:</div>
              </div>
              <div>
                <span className="font-bold">Страница: </span>
                <span className="font-mono font-bold">3</span>
                <div className="italic text-[9px] text-slate-600">Page:</div>
              </div>
              <div className="font-mono font-bold text-xs">{info.issueDate}</div>
            </div>

            {/* Title */}
            <div className="my-2">
              <h3 className="font-bold text-xs">
                Результаты калибровки, включая неопределенность
              </h3>
              <div className="italic text-[10px] text-slate-600">
                Calibration results including uncertainty
              </div>
            </div>

            {/* Results Table */}
            <table className="w-full border-collapse border border-black text-xs text-center my-2">
              <thead>
                <tr className="bg-slate-100 font-bold">
                  <th className="border border-black p-1.5">
                    Калибруемая точка, °С
                    <br />
                    <span className="italic font-normal text-[9px]">Calibration point</span>
                  </th>
                  <th className="border border-black p-1.5">
                    Опорное значение (Центр N5), °С
                    <br />
                    <span className="italic font-normal text-[9px]">Reference value</span>
                  </th>
                  <th className="border border-black p-1.5">
                    Показание шкафа, °С
                    <br />
                    <span className="italic font-normal text-[9px]">
                      Indication of the calibration object
                    </span>
                  </th>
                  <th className="border border-black p-1.5">
                    Отклонение показания, °С
                    <br />
                    <span className="italic font-normal text-[9px]">Deviation of the reading</span>
                  </th>
                  <th className="border border-black p-1.5">
                    Расширенная неопределенность U, °С
                    <br />
                    <span className="italic font-normal text-[9px]">Extended uncertainty</span>
                  </th>
                </tr>
              </thead>
              <tbody>
                <tr className="font-mono font-medium">
                  <td className="border border-black p-2">{formatMetrologyNumber(pointTemp, 2)}</td>
                  <td className="border border-black p-2">{formatMetrologyNumber(refValue, 3)}</td>
                  <td className="border border-black p-2">{formatMetrologyNumber(indValue, 2)}</td>
                  <td className="border border-black p-2 font-bold">
                    {formatMetrologyNumber(devValue, 3)}
                  </td>
                  <td className="border border-black p-2 font-bold text-emerald-900">
                    ±{formatMetrologyNumber(extUncertainty, 2)}
                  </td>
                </tr>
              </tbody>
            </table>

            {/* 9 Points Spatial Distribution Table */}
            <div className="mt-3">
              <div className="font-bold text-[11px]">
                Распределение температуры по точкам объема рабочей камеры:
              </div>
              <div className="italic text-[9px] text-slate-600 mb-1">
                Temperature distribution across chamber volume points:
              </div>

              <table className="w-full border-collapse border border-black text-center text-[10px]">
                <thead>
                  <tr className="bg-slate-100 font-bold">
                    <th className="border border-black p-1">Точка (ID)</th>
                    <th className="border border-black p-1">Расположение в объеме камеры</th>
                    <th className="border border-black p-1">T_std, среднее (°C)</th>
                    <th className="border border-black p-1">Отклонение от центра |T_ref - T_i| (°C)</th>
                  </tr>
                </thead>
                <tbody>
                  {pointsData.map((pt) => {
                    const stat = calculation.pointStats[pt.id];
                    return (
                      <tr key={pt.id} className="font-mono">
                        <td className="border border-black p-1 font-bold">
                          {pt.id} {pt.isCenter ? '(Центр)' : ''}
                        </td>
                        <td className="border border-black p-1 font-sans text-left text-[9px]">
                          {pt.nameRu} ({pt.positionDesc})
                        </td>
                        <td className="border border-black p-1">
                          {stat && stat.isEntered ? formatMetrologyNumber(stat.meanStd, 3) : '—'}
                        </td>
                        <td className="border border-black p-1">
                          {stat && stat.isEntered ? formatMetrologyNumber(stat.diffFromCenter, 3) : '—'}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {/* Inhomogeneity & Instability sub-table */}
            <div className="mt-3 flex justify-center">
              <table className="w-full border-collapse border border-black text-xs">
                <thead>
                  <tr>
                    <th className="border border-black p-1 text-left w-3/4">Параметр однородности и стабильности</th>
                    <th className="border border-black p-1 text-center font-mono font-bold bg-slate-50">
                      Значение при {pointTemp} °C
                    </th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td className="border border-black p-1.5">
                      <span className="font-bold">Наибольшая неоднородность в полезном объеме (δT_inhom), °С</span>
                      <br />
                      <span className="italic text-[10px] text-slate-600">
                        The greatest spatial inhomogeneity across 9 volume points, °C
                      </span>
                    </td>
                    <td className="border border-black p-1.5 text-center font-mono font-bold">
                      {formatMetrologyNumber(inhomValue, 3)}
                    </td>
                  </tr>
                  <tr>
                    <td className="border border-black p-1.5">
                      <span className="font-bold">
                        Наибольшая временная нестабильность поддержания температуры (δT_instab), °С
                      </span>
                      <br />
                      <span className="italic text-[10px] text-slate-600">
                        The greatest temporary instability of temperature maintenance, °C
                      </span>
                    </td>
                    <td className="border border-black p-1.5 text-center font-mono font-bold">
                      {formatMetrologyNumber(instabValue, 3)}
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>

            {/* Additional Information */}
            <div className="my-2">
              <div className="font-bold text-xs">Дополнительная информация:</div>
              <div className="italic text-[10px] text-slate-600">Additional information</div>
              <div className="mt-0.5 font-mono text-slate-700">{info.additionalInfo || '-------'}</div>
            </div>

            {/* Anti-tampering Security Hatching Lines */}
            <div className="my-2 border border-slate-300 relative h-36 overflow-hidden rounded">
              <svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
                <defs>
                  <pattern
                    id="diagonalHatch"
                    width="20"
                    height="20"
                    patternTransform="rotate(45 0 0)"
                    patternUnits="userSpaceOnUse"
                  >
                    <line x1="0" y1="0" x2="0" y2="20" stroke="#000000" strokeWidth="1.2" />
                  </pattern>
                </defs>
                <rect width="100%" height="100%" fill="url(#diagonalHatch)" />
              </svg>
            </div>
          </div>

          {/* Official Footer */}
          <div className="border-t border-black pt-2 text-[8px] text-slate-700 flex justify-between items-center">
            <div>
              <span className="font-bold">F.G104.C</span>
              <br />
              (2025-10-27)
            </div>
            <div className="text-center flex-1 px-4 leading-tight">
              Узбекистан, 100174, Ташкент, Алмазарский район, улица Фаробий, 333 А, 333 Б www.nim.uz
              <br />
              333 A, 333 B, Farobiy street, Almazar district, Tashkent, 100174, Uzbekistan www.nim.uz
            </div>
          </div>
        </div>

        {/* ==================== PAGE 4 ==================== */}
        <div
          id="cert-page-4"
          className={`w-[210mm] min-h-[297mm] h-[297mm] p-[16mm] bg-white text-black shadow-2xl relative font-sans text-[11px] leading-snug flex-col justify-between box-border shrink-0 print:shadow-none print:m-0 print:p-[12mm] ${
            currentPage === 'all' || currentPage === 4 ? 'flex' : 'hidden print:flex'
          }`}
          style={{ fontFamily: 'Arial, sans-serif' }}
        >
          <div>
            {/* Header */}
            <div className="flex items-start justify-between border-b border-black pb-2 text-[10px]">
              <div>
                <div className="font-bold uppercase">УЗБЕКСКИЙ НАЦИОНАЛЬНЫЙ ИНСТИТУТ МЕТРОЛОГИИ</div>
                <div className="italic text-slate-700 uppercase">
                  UZBEK NATIONAL INSTITUTE OF METROLOGY
                </div>
              </div>
              <div className="border border-black px-2 py-0.5 text-center font-bold">
                <div>Z/0000-</div>
                <div className="text-[8px]">OʻZAK. KL.0013</div>
              </div>
            </div>

            {/* Sub-header meta */}
            <div className="flex justify-between items-center py-2 text-xs border-b border-slate-300">
              <div>
                <span className="font-bold">Номер сертификата: </span>
                <span className="font-mono font-bold underline">{info.certificateNumber}</span>
                <div className="italic text-[9px] text-slate-600">Certificate number:</div>
              </div>
              <div>
                <span className="font-bold">Страница: </span>
                <span className="font-mono font-bold">4</span>
                <div className="italic text-[9px] text-slate-600">Page:</div>
              </div>
              <div className="font-mono font-bold text-xs">{info.issueDate}</div>
            </div>

            {/* Statements */}
            <div className="space-y-4 my-5 text-xs text-justify">
              <div>
                <p className="font-bold">
                  Указанная расширенная неопределенность измерений определяется как стандартная неопределенность измерений, умноженная на коэффициент охвата k = 2, что для нормального распределения соответствует вероятности охвата приблизительно 95 %. Стандартная неопределенность измерений определена в соответствии с GUM.
                </p>
                <p className="italic text-[10px] text-slate-600 mt-1">
                  The reported expanded uncertainty of measurement is stated as the standard uncertainty of measurement multiplied by the coverage factor k = 2, which for a normal distribution corresponds to a coverage probability of approximately 95 %. The standard uncertainty of measurement has been determined in accordance with GUM.
                </p>
              </div>

              <div className="border-t border-slate-200 pt-3">
                <p className="font-bold text-center">
                  Все измерения имеют прослеживаемость к единицам Международной системы SI
                  <br />
                  <span className="italic font-normal text-[10px] text-slate-600">
                    All measurements are traceable to the SI units
                  </span>
                </p>
              </div>

              <div className="border-t border-slate-200 pt-2">
                <p className="font-bold text-center">
                  Результат калибровки относится только к объекту калибровки
                  <br />
                  <span className="italic font-normal text-[10px] text-slate-600">
                    The calibration result refers only to the calibration item
                  </span>
                </p>
              </div>

              {/* Institutional Box */}
              <div className="border border-black p-3.5 space-y-3 text-[10px] leading-snug my-4">
                <div>
                  <p className="font-bold">
                    Узбекский национальный институт метрологии является подписантом Договорённости о взаимном признании (MRA) Международного комитета по весам и мерам (CIPM).
                  </p>
                  <p className="italic text-slate-600">
                    Uzbek National Institute of Metrology is a signatory of the International Committee for Weights and Measures (CIPM) Mutual Recognition Arrangement (MRA).
                  </p>
                </div>

                <div className="border-t border-slate-300 pt-2">
                  <p className="font-bold">
                    Узбекский национальный институт метрологии аккредитован Узбекским центром аккредитации (O‘ZAKK) под регистрационным номером O‘ZAK.KL.0006 по O‘z DSt ISO/IEC 17025:2019 как калибровочная лаборатория.
                  </p>
                  <p className="italic text-slate-600">
                    Uzbek National Institute of Metrology accredited by Uzbek Accreditation Center (O‘ZAKK) under registration number O‘ZAK.KL.0006 for O‘z DSt ISO/IEC 17025:2019 as Calibration Laboratory.
                  </p>
                </div>

                <div className="border-t border-slate-300 pt-2">
                  <p className="font-bold">
                    Узбекский центр аккредитации (O‘ZAKK) является подписантом Договорённости о взаимном признании (MRA) Азиатско-Тихоокеанского сотрудничества по аккредитации (APAC) и Договоренности о взаимном признании (MRA) Международного сотрудничества по аккредитации лабораторий (ILAC) для признания сертификатов калибровки.
                  </p>
                  <p className="italic text-slate-600">
                    Uzbek Accreditation Center (O‘ZAKK) is a signatory to the Asia Pacific Accreditation Cooperation (APAC) Mutual Recognition Arrangement (MRA) and to the International Laboratory Accreditation Cooperation (ILAC) Mutual Recognition Arrangement (MRA) for the recognition of calibration certificates.
                  </p>
                </div>
              </div>

              {/* Customer Feedback & QR Code Block */}
              <div className="flex items-center justify-end gap-5 pt-4">
                <div className="text-right text-[10px] max-w-xs">
                  <p className="font-bold">
                    Калибровочная лаборатория УзНИМ стремится получать обратную связь от своих заказчиков
                  </p>
                  <p className="italic text-slate-600 mt-0.5">
                    UzNIM Calibration laboratory seeks feedback from its customers
                  </p>
                </div>
                <QrCodeSvg size={76} text={`e-metrologiya.uz/${info.certificateNumber}`} />
              </div>

              {/* End of Certificate notice */}
              <div className="text-center font-bold text-sm pt-4">
                <div>Конец сертификата калибровки</div>
                <div className="italic font-normal text-xs text-slate-600">
                  End of Calibration Certificate
                </div>
              </div>
            </div>
          </div>

          {/* Official Footer */}
          <div className="border-t border-black pt-2 text-[8px] text-slate-700 flex justify-between items-center">
            <div>
              <span className="font-bold">F.G104.C</span>
              <br />
              (2025-10-27)
            </div>
            <div className="text-center flex-1 px-4 leading-tight">
              Узбекистан, 100174, Ташкент, Алмазарский район, улица Фаробий, 333 А, 333 Б www.nim.uz
              <br />
              333 A, 333 B, Farobiy street, Almazar district, Tashkent, 100174, Uzbekistan www.nim.uz
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
