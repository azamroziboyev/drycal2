export type ChamberPointId = 'N1' | 'N2' | 'N3' | 'N4' | 'N5' | 'N6' | 'N7' | 'N8' | 'N9';

export interface ChamberMeasurementRow {
  index: number;
  tStd: number | string; // Etalon ko'rsatkichi, °C
  tInd: number | string; // Quritish shkafi ko'rsatkichi, °C
}

export interface ChamberPointData {
  id: ChamberPointId;
  nameUz: string;
  nameRu: string;
  positionDesc: string;
  coord: [number, number, number]; // 3D coordinates for Three.js
  isCenter: boolean;
  rows: ChamberMeasurementRow[];
}

export interface CalibrationItemInfo {
  certificateNumber: string;
  orderNumber: string;
  contractNumber: string;
  applicationDate: string;
  contractDate: string;
  issueDate: string;
  calibrationPeriod: string;
  receptionTime: string;
  calibrationTime: string;
  customerName: string;
  customerAddress?: string;
  objectName: string;
  objectType: string;
  serialNumber: string;
  resolution: number; // e.g. 0.1 °C or 0.01 °C
  tempRangeMin: number; // e.g. 0 °C
  tempRangeMax: number; // e.g. 50 °C or 300 °C
  calibrationPoints: number[]; // e.g. [30] or [50]
  manufacturer: string;
  
  // Reference standards used
  standardName: string;
  standardType: string;
  standardSerial: string;
  standardTraceability: string;
  standardCertUncertainty: number; // U_cal.std e.g. 0.1 °C
  standardResolution: number; // rez_std e.g. 0.001 °C
  standardDrift: number; // delta_d e.g. 0.0 °C
  
  // Radiation and loading effect parameters
  deltaRadiation: number; // Max |T_le - T_he| (typically 0.075 or calculated)
  deltaLoad: number; // Max |T_ref - T_ref.load| (typically 0.092 or calculated)
  
  // Ambient conditions
  ambientTempMin: number;
  ambientTempMax: number;
  relativeHumidityMin: number;
  relativeHumidityMax: number;
  atmosphericPressureMin?: number;
  atmosphericPressureMax?: number;
  
  // Personnel
  calibratedByUz: string;
  calibratedByRu: string;
  checkedByUz: string;
  checkedByRu: string;
  laboratoryNameUz: string;
  laboratoryNameRu: string;
  laboratoryNameEn: string;
  additionalInfo?: string;
}

export interface PointStat {
  id: ChamberPointId;
  name: string;
  meanStd: number;
  meanInd: number;
  diffFromCenter: number; // ABS | T_ref - T_i |
  isEntered: boolean;
  count: number;
}

export interface ChamberCalculation {
  pointTemp: number; // calibration target temperature (e.g. 30 °C, 50 °C)
  n: number; // number of readings per point (usually 10)
  totalFilledPoints: number; // how many of the 9 points have data
  
  // Per point stats
  pointStats: Record<ChamberPointId, PointStat>;
  
  // Center reference point (N5)
  centerStdMean: number;
  centerIndMean: number;
  
  // Overall means
  overallStdMean: number;
  overallIndMean: number;
  deviation: number; // T_std - T_ind (or T_ind - T_std)
  
  // Instability & Inhomogeneity
  instabilityDelta: number; // delta T_instab = Max | T_bar - T_i |
  inhomogeneityDelta: number; // delta T_inhom = Max | T_ref - T_i |
  radiationDelta: number; // delta T_radiation = 0.2 * Max | T_le - T_he |
  loadDelta: number; // delta T_load = 0.2 * Max | T_ref - T_ref,load |
  
  // Uncertainty components according to KU-10-2025
  u_a1: number; // Standard Type A
  u_a2: number; // Indicator Type A
  u_b1: number; // Instability: delta_instab / sqrt(3)
  u_b2: number; // Inhomogeneity: delta_inhom / sqrt(3)
  u_b3: number; // Radiation: 0.2 * delta_radiation / sqrt(3)
  u_b4: number; // Load: 0.2 * delta_load / sqrt(3)
  u_b5: number; // Standard cert: U_cal.std / 2
  u_b6: number; // Standard resolution: rez_std / (2 * sqrt(3))
  u_b7: number; // Chamber resolution: rez_therm / (2 * sqrt(3))
  u_b8: number; // Drift: delta_d / sqrt(3)
  
  // Combined and expanded
  u_c: number;
  k: number;
  U: number;
  v_eff: number | string;
}

export interface SavedCertificate {
  id: string;
  createdAt: string;
  certificateNumber: string;
  customerName: string;
  objectName: string;
  objectType: string;
  serialNumber: string;
  issueDate: string;
  info: CalibrationItemInfo;
  pointsData: ChamberPointData[];
  calculation: ChamberCalculation;
  deviceInfo?: string;
}

export interface LoginAuditLog {
  id: string;
  timestamp: string;
  username: string;
  deviceType: 'Desktop' | 'Mobile' | 'Tablet';
  browser: string;
  os: string;
  userAgent: string;
  screenResolution: string;
  ipAddress: string;
  status: 'Muvaffaqiyatli' | 'Xato parol' | 'Chiqish';
  actionNote?: string;
}
