import React, { useState, useEffect } from 'react';
import { Lock, User, ShieldCheck, Laptop, AlertCircle, ArrowRight, Eye, EyeOff } from 'lucide-react';
import { UzNimLogo } from './UzNimLogo';
import { getDeviceInfo, recordAuditLog, setAuthSession } from '../utils/storage';

interface LoginScreenProps {
  onLoginSuccess: (username: string) => void;
}

export const LoginScreen: React.FC<LoginScreenProps> = ({ onLoginSuccess }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);
  const [errorMessage, setErrorMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [deviceDetails, setDeviceDetails] = useState<{
    deviceType: string;
    browser: string;
    os: string;
    screenResolution: string;
  } | null>(null);

  useEffect(() => {
    setDeviceDetails(getDeviceInfo());
  }, []);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setErrorMessage('');

    setTimeout(() => {
      // Credentials requested by user: login: metrologiya, parol: 12345
      if (username.trim().toLowerCase() === 'metrologiya' && password === '12345') {
        recordAuditLog('metrologiya', 'Muvaffaqiyatli', 'Tizimga kirish tasdiqlandi');
        setAuthSession('metrologiya', rememberMe);
        setIsLoading(false);
        onLoginSuccess('metrologiya');
      } else {
        setIsLoading(false);
        setErrorMessage('Login yoki parol noto‘g‘ri! (Login: metrologiya, Parol: 12345)');
        recordAuditLog(
          username || 'Nomaʼlum',
          'Xato parol',
          `Noto'g'ri urinish: login='${username}', parol='***'`
        );
      }
    }, 350);
  };

  const handleFillDemo = () => {
    setUsername('metrologiya');
    setPassword('12345');
    setErrorMessage('');
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-slate-100 via-blue-50 to-slate-200 dark:from-slate-950 dark:via-slate-900 dark:to-slate-950 transition-colors duration-300">
      <div className="w-full max-w-md">
        {/* Card */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-xl border border-slate-200 dark:border-slate-800 p-8">
          {/* Header */}
          <div className="text-center mb-6">
            <div className="flex justify-center mb-3">
              <div className="p-2 bg-white rounded-xl shadow-xs border border-slate-100 dark:border-slate-800 inline-flex items-center justify-center">
                <UzNimLogo size={60} />
              </div>
            </div>
            <h1 className="text-xl font-bold text-slate-900 dark:text-white tracking-tight">
              O‘zbekiston Milliy Metrologiya Instituti
            </h1>
            <p className="text-xs font-semibold text-blue-700 dark:text-blue-400 mt-1 uppercase tracking-wider">
              Kalibrlash Sertifikatlari va Noaniqlik Tizimi
            </p>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              Elektron kalibrlash va hisobot platformasi
            </p>
          </div>

          {/* Error notification */}
          {errorMessage && (
            <div className="mb-5 p-3 rounded-xl bg-red-50 dark:bg-red-950/50 border border-red-200 dark:border-red-900 flex items-start gap-2.5 text-red-700 dark:text-red-300 text-xs">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-red-500" />
              <div>
                <p className="font-semibold">Kirish rad etildi</p>
                <p className="mt-0.5">{errorMessage}</p>
              </div>
            </div>
          )}

          {/* Form */}
          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label 
                htmlFor="username-input" 
                className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5"
              >
                Foydalanuvchi logini (Metrologiya)
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                  <User className="w-4 h-4" />
                </div>
                <input
                  id="username-input"
                  type="text"
                  required
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="Loginni kiriting"
                  autoComplete="off"
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 transition-colors"
                />
              </div>
            </div>

            <div>
              <label 
                htmlFor="password-input" 
                className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5"
              >
                Parol (12345)
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                  <Lock className="w-4 h-4" />
                </div>
                <input
                  id="password-input"
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Parolni kiriting"
                  autoComplete="off"
                  className="w-full pl-10 pr-10 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 transition-colors"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  aria-label={showPassword ? "Parolni berkitish" : "Parolni ko'rsatish"}
                  className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <div className="flex items-center justify-between text-xs pt-1">
              <label className="flex items-center gap-2 cursor-pointer text-slate-600 dark:text-slate-400">
                <input
                  type="checkbox"
                  checked={rememberMe}
                  onChange={(e) => setRememberMe(e.target.checked)}
                  className="rounded border-slate-300 text-blue-600 focus:ring-blue-500 w-4 h-4"
                />
                Eslab qolish
              </label>
              <button
                type="button"
                onClick={handleFillDemo}
                className="text-blue-600 hover:text-blue-700 dark:text-blue-400 font-medium hover:underline"
              >
                Namuna parolni to‘ldirish
              </button>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl font-medium text-sm text-white bg-blue-700 hover:bg-blue-800 active:bg-blue-900 shadow-md shadow-blue-500/20 disabled:opacity-70 transition-all cursor-pointer"
            >
              {isLoading ? (
                <span>Tekshirilmoqda...</span>
              ) : (
                <>
                  <span>Tizimga kirish</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>

          {/* Device information banner (User requirement: device audit tracking) */}
          {deviceDetails && (
            <div className="mt-6 pt-5 border-t border-slate-200 dark:border-slate-800">
              <div className="flex items-center gap-2 text-slate-600 dark:text-slate-400 text-xs mb-2 font-medium">
                <Laptop className="w-4 h-4 text-slate-400" />
                <span>Aniqlangan qurilma parametrlari:</span>
              </div>
              <div className="grid grid-cols-2 gap-2 text-[11px] bg-slate-50 dark:bg-slate-800/60 p-2.5 rounded-lg text-slate-600 dark:text-slate-300 border border-slate-200/60 dark:border-slate-700/60">
                <div>
                  <span className="text-slate-400 block text-[10px]">Turi / OT:</span>
                  <span className="font-semibold">{deviceDetails.deviceType} • {deviceDetails.os}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px]">Brauzer:</span>
                  <span className="font-semibold truncate block">{deviceDetails.browser}</span>
                </div>
                <div className="col-span-2 flex items-center justify-between pt-1 border-t border-slate-200/40 dark:border-slate-700/40">
                  <span className="text-[10px] text-slate-400">Ekran o‘lchami: {deviceDetails.screenResolution}</span>
                  <span className="inline-flex items-center gap-1 text-[10px] text-emerald-600 dark:text-emerald-400 font-medium">
                    <ShieldCheck className="w-3 h-3" /> Audit jurnalga yoziladi
                  </span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer info */}
        <div className="text-center mt-5 text-xs text-slate-500 dark:text-slate-400">
          <p>Kalibrlash laboratoriyasi avtomatlashtirilgan axborot tizimi</p>
        </div>
      </div>
    </div>
  );
};
